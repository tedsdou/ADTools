function Set-RbaMaxPosNegPhaseCorrection
{
	<#
	.SYNOPSIS
   		Set-RbaMaxPosNegPhaseCorrection is a Powershell function that set MaxPosPhaseCorrection or MaxNegPhaseCorrection value.
	.DESCRIPTION
   		Set-RbaMaxPosNegPhaseCorrection is a Powershell function that set MaxPosPhaseCorrection or MaxNegPhaseCorrection value.
    .PARAMETER TargetComputer
		TargetComputer, has to be FQDN or Computer Name.
	.PARAMETER MaxPosPhaseCorrectionTime
		New MaxPosPhaseCorrection value in seconds.
    .PARAMETER MaxNegPhaseCorrectionTime
		New MaxNegPhaseCorrection value in seconds.
	.EXAMPLE
		Set-RbaMaxPosNegPhaseCorrection -DomainController LocalComputerName -MaxPosPhaseCorrection 172800

		Set MaxPosPhaseCorrection to 48 hours (172800 s) for local computer.
	.EXAMPLE
		Set-RbaMaxPosNegPhaseCorrection  -DomainController Computer1,Computer2 -MaxNegPhaseCorrectionTime 86400

		Set MaxNegPhaseCorrection to 24 hours (86400 s) for Computer1 and Computer2.
    .EXAMPLE
		Set-RbaMaxPosNegPhaseCorrection  -DomainController Computer1,Computer2 -MaxPosPhaseCorrectionTime 86400

		Set MaxPosPhaseCorrection to 24 hours (86400 s) for Computer1 and Computer2.
	.NOTES
        It requires PS version 2.0, 3.0, or 4.0.
		
	#>
    [CmdletBinding(SupportsShouldProcess=$true, ConfirmImpact="High")]
	param
	( 
        [Parameter(Mandatory=$true)]
		[array]$DomainController,
 		[Parameter(Mandatory=$true, ParameterSetName= "MaxPosParameterSet")]
		[int]$MaxPosPhaseCorrectionTime,
        [Parameter(Mandatory=$true, ParameterSetName= "MaxNegParameterSet")]
		[int]$MaxNegPhaseCorrectionTime   
	)

    #---------------------------------------
	# Preparing process
	#---------------------------------------
    begin
	{
		# Setting up environment
		Set-StrictMode -Version 2.0
		
		if (!(Test-RbaSupportedEnv))
		{
			$UnsupportedEnvMessage | Add-RbaLogEntry -Severity ([Severity]::Error) -NoConsoleOutput
			throw ($UnsupportedEnvMessage)
		}	
		
		$ErrorActionPreference = [System.Management.Automation.ActionPreference]::Stop
	}


    #---------------------------------------
	# Main function process
	#---------------------------------------
    Process
    {
	    try
	    {
            
            foreach($computerName in $DomainController)
            {
                if($PSCmdlet.ShouldProcess($computerName))
	            {
     
					"Connecting $computerName remote registry..." | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
                    $reg=[Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey('LocalMachine', $computerName)

					"Openning SubKey SYSTEM\CurrentControlSet\services\W32Time\config ..." | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
                    $key=$reg.OpenSubKey('SYSTEM\CurrentControlSet\services\W32Time\config', $true)

                    # Decide which parameter is being changed
                    if ($PSCmdlet.ParameterSetName -eq "MaxPosParameterSet")
                    {
						"Setting MaxPosPhaseCorrection..." | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
                        $key.SetValue('MaxPosPhaseCorrection',$MaxPosPhaseCorrectionTime)
                    }
                    else
                    {
						"Setting MaxNegPhaseCorrection..." | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
                        $key.SetValue('MaxNegPhaseCorrection',$MaxNegPhaseCorrectionTime)
                    }
                    
					"Closing $key..." | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
                    $key.Close()

                    "Closing $reg..." | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
                    $reg.Close()
   
                }
            }
            
	    }
	    catch
	    {
			"An error ocurred trying to change MaxPosPhaseCorrection or  MaxNegPhaseCorrection." | Log-ErrorToFile -Error $_
		    Write-Error "An error ocurred trying to change MaxPosPhaseCorrection or  MaxNegPhaseCorrection. Error details: $_"	
	    }
    }

	end
	{
		"End of Script" | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
	}
}

#------------------------------------------------
# Dot sourcing internal functions used by cmdlets
#------------------------------------------------
. (Join-Path ([System.IO.Path]::GetDirectoryName($MyInvocation.MyCommand.Definition)) "Microsoft.Rba.LogFunctions.ps1")
. (Join-Path ([System.IO.Path]::GetDirectoryName($MyInvocation.MyCommand.Definition)) "Microsoft.Rba.CoreHelper.ps1")
