﻿function Set-RbaGlobalCatalog
{
	<#
	.SYNOPSIS
   		Set-RbaGlobalCatalog is a Powershell function that changes status of a domain controller regarding global catalog function.
	.DESCRIPTION
   		Set-RbaGlobalCatalog is a Powershell function that changes status of a domain controller regarding global catalog function.
		It can make domain controller a global catalog or it can remove global catalog from a domain controller.
	.PARAMETER DomainController
		Performs the operation on a specific Domain controller, can be FQDN or NetBIOSName.
	.PARAMETER EnableGC
		Enables DC as global catalog if not already GC.
	.PARAMETER DisableGC
		Removes global catalog of DC.
	.EXAMPLE
		Set-RbaGlobalCatalog -DomainController "dc01.contoso.com","dc02.contoso.com" -EnableGC
		
		Configures DCs as global catalog by using -Domaincontroller parameter. 
	.EXAMPLE
		Get-RbaNonGCDomainController | Set-RbaGlobalCatalog -EnableGC
		
		Configures DC as global catalog by accepting values from pipeline as a result of another cmdlet.
	.RETURNS
		List of System.DirectoryServices.ActiveDirectory.DomainController of affected DCs.

	.NOTES
		Must be executed on a domain with a domain admin account.
	#>
	[CmdletBinding(SupportsShouldProcess=$true,ConfirmImpact="High")]
	param
	(                                
 		[parameter(Mandatory=$true,ValueFromPipeline=$true)]
		$DomainController,

 		[parameter(Mandatory=$true, ParameterSetName="EnableGC")]
		[switch]$EnableGC,

 		[parameter(Mandatory=$true, ParameterSetName="DisableGC")]
		[switch]$DisableGC
	)

	begin
	{
		# Setting up environment
		Set-StrictMode -Version 2.0
		
		if (!(Test-RbaSupportedEnv))
		{
			$UnsupportedEnvMessage | Add-RbaLogEntry -Severity ([Severity]::Error) -NoConsoleOutput
			throw ($UnsupportedEnvMessage)
		}	
	
		$ErrorActionPreference = [System.Management.Automation.ActionPreference]::Stop

		$affectedDCs = @()
	}
	
	process
	{
		foreach($dc in $DomainController)
        {
			try
			{
			
				if (!($dc.GetType().Name -ieq "DomainController"))
				{
					"Getting DC object with name $dc ..." | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
					$resultantDC = (Get-RbaADDomainController -Scope ([QueryScope]::Computer) -ScopeValue $dc)[0]
				}
				else
				{
					"DC object $($dc.name) is already a DomainController object..." | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
					$resultantDC = $dc
				}
			
				if ($resultantDC -ne $null)
				{
					$context = New-Object -TypeName System.DirectoryServices.ActiveDirectory.DirectoryContext -ArgumentList ([System.DirectoryServices.ActiveDirectory.DirectoryContextType]::DirectoryServer), $resultantDC.Name
					$changingDC = [System.DirectoryServices.ActiveDirectory.DomainController]::GetDomainController($context)

					if ($PSCmdlet.ParameterSetName -eq "EnableGC")
					{
						if ($PSCmdlet.ShouldProcess($resultantDC.Name,"Enable GC"))
						{
							"Making $($resultantDC.Name) a Global Catalog" | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
							
							if (!$changingDC.IsGlobalCatalog())
							{
								$changingDC.EnableGlobalCatalog()
								$affectedDCs += $resultantDC
							}
						}
					}
					else
					{
						if ($PSCmdlet.ShouldProcess($resultantDC.Name,"Disable GC"))
						{
							"Removing Global Catalog from $($resultantDC.Name) " | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
							if ($changingDC.IsGlobalCatalog())
							{
								$context = New-Object -TypeName System.DirectoryServices.ActiveDirectory.DirectoryContext -ArgumentList ([System.DirectoryServices.ActiveDirectory.DirectoryContextType]::DirectoryServer), $resultantDC.Name         
								$gc = [System.DirectoryServices.ActiveDirectory.GlobalCatalog]::GetGlobalCatalog($context)
								$gc.DisableGlobalCatalog()
								$affectedDCs += $resultantDC
							}
						}
					}
				}
				else
				{
					"DC named $dc returned null from AD query, no action will be taken." | Add-RbaLogEntry -Severity ([Severity]::Warn) -NoConsoleOutput
				}
			}
			catch
			{
				"An error ocurred processing domain controller $dc. Error details: $_" | Add-RbaLogEntry -Severity ([Severity]::Warn) -NoConsoleOutput
			}
		}
	}

	end
	{
		"End of Script" | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
		return $affectedDCs
	}
}

#------------------------------------------------
# Dot sourcing internal functions used by cmdlets
#------------------------------------------------
. (Join-Path ([System.IO.Path]::GetDirectoryName($MyInvocation.MyCommand.Definition)) "Microsoft.Rba.LogFunctions.ps1")
. (Join-Path ([System.IO.Path]::GetDirectoryName($MyInvocation.MyCommand.Definition)) "Microsoft.Rba.CoreHelper.ps1")
