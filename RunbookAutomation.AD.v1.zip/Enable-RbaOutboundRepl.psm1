function Enable-RbaOutboundRepl
{
	<#
	.SYNOPSIS
   		Enable-RbaOutboundRepl is a Powershell function that enables outbound replication on a list of domain controllers.
	.DESCRIPTION
   		Enable-RbaOutboundRepl is a Powershell function that enables outbound replication on a list of domain controllers.
	.PARAMETER DomainController
		Domain controller name specified as a FQDN.
	.EXAMPLE
        Get-RbaDCOutboundReplDisabled | Enable-RbaOutboundRepl

        Enables outbound replication on a list of domain controllers returned from Get-RbaDCOutboundReplDisabled.
	.EXAMPLE
		Enable-RbaOutboundRepl -DomainController DC01.contoso.com

        Enables outbound replication on DC01.contoso.com domain controller.
	.EXAMPLE
		Enable-RbaOutboundRepl -DomainController DC01.contoso.com,DC02.contoso.com

        Enables outbound replication on DC01.contoso.com and DC02.contoso.com domain controllers.
	.NOTES
		Must be executed with an enterprise admin account.
	#>

	[CmdletBinding(SupportsShouldProcess=$true, ConfirmImpact="High")]
    param
	(
		[Parameter(Mandatory=$true,Position=0,ValueFromPipeline=$true)]
		[string[]]$DomainController
	)

    begin
    {
		# Setting up environment
		$ErrorActionPreference = [System.Management.Automation.ActionPreference]::Stop

		Set-StrictMode -Version 2.0
		
		if (!(Test-RbaSupportedEnv))
		{
			$UnsupportedEnvMessage | Add-RbaLogEntry -Severity ([Severity]::Error) -NoConsoleOutput
			throw ($UnsupportedEnvMessage)
		}	

        Set-Variable -Name DISABLE_OUTBOUND_REPL -Value 4 -Option Constant -WhatIf:$false
		$configurationNamingContext = (New-Object DirectoryServices.DirectoryEntry("LDAP://RootDSE")).configurationNamingContext
    }

    process
    {
        foreach ($dc in $DomainController)
        {
            try
            {
				$dcObj = (Get-RbaADDomainController -Scope ([QueryScope]::Computer) -ScopeValue $dc)[0]
				
				if ($dcObj -ne $null)
				{
					$dn = (GetRbaADObject -LDAPFilter "(dNSHostName=$($dcObj.Name))" -DomainController $dcObj.Name -Property DistinguishedName -SearchRoot $configurationNamingContext -SearchScope ([System.DirectoryServices.SearchScope]::SubTree)).DistinguishedName
                
					$options = (GetRbaADObject -Identity "CN=NTDS Settings,$dn" -DomainController $dcObj.Name -Property options).options
				
					$options = $options -bxor $DISABLE_OUTBOUND_REPL

					if ($PSCmdlet.ShouldProcess($dc, "Enabling outbound replication"))
					{
						Set-RbaADObject -Identity "CN=NTDS Settings,$dn" -Replace @{options=$options} -DomainController $dcObj.Name
					}
				}
            }
            catch
            {
                Write-Error "Exception on $dc`n$_" -ErrorAction "Continue"
            }
        }
    }
}

#------------------------------------------------
# Dot sourcing internal functions used by cmdlets
#------------------------------------------------
. (Join-Path ([System.IO.Path]::GetDirectoryName($MyInvocation.MyCommand.Definition)) "Microsoft.Rba.LogFunctions.ps1")
. (Join-Path ([System.IO.Path]::GetDirectoryName($MyInvocation.MyCommand.Definition)) "Microsoft.Rba.CoreHelper.ps1")
