function Get-RbaDCInboundReplDisabled
{
	<#
	.SYNOPSIS
   		Get-RbaDCInboundReplDisabled is a Powershell function that returns a list of domain controllers that have inbound replication disabled.
	.DESCRIPTION
   		Get-RbaDCInboundReplDisabled is a Powershell function that returns a list of domain controllers that have inbound replication disabled.
		This function performs forest wide search or checks a DC based on a parameter that was specified.
	.PARAMETER DomainController
		Domain controller name specified as a FQDN.
	.EXAMPLE
        Get-RbaDCInboundReplDisabled

        Performs forest wide search for a domain controllers with inbound replication disabled.
	.EXAMPLE
		Get-RbaDCInboundReplDisabled -DomainController DC01.contoso.com

        Checks if inbound replication is disabled on DC01.contoso.com domain controller.
	.NOTES
		Must be executed with an enterprise admin account logged on a domain controller.
    .OUTPUTS
        System.String
        Get-RbaDCInboundReplDisabled returns objects that represent domain controllers with inbound replication disabled.
	#>

    [CmdletBinding()]
    param
	(
		[Parameter(Mandatory=$false,Position=0)]
		[String]$DomainController
	)

	# Setting up environment
	$ErrorActionPreference = [System.Management.Automation.ActionPreference]::Stop

	Set-StrictMode -Version 2.0
		
	if (!(Test-RbaSupportedEnv))
	{
		$UnsupportedEnvMessage | Add-RbaLogEntry -Severity ([Severity]::Error) -NoConsoleOutput
		throw ($UnsupportedEnvMessage)
	}	

    Set-Variable -Name DISABLE_INBOUND_REPL -Value 2 -Option Constant

    if (!([string]::IsNullOrEmpty($DomainController)))
    {
       return ,(CheckNTDSConfig -option $DISABLE_INBOUND_REPL -DomainController $DomainController)
    }
    else
    {
        return ,(CheckNTDSConfig -option $DISABLE_INBOUND_REPL)
    }
}

#------------------------------------------------
# Dot sourcing internal functions used by cmdlets
#------------------------------------------------
. (Join-Path ([System.IO.Path]::GetDirectoryName($MyInvocation.MyCommand.Definition)) "Microsoft.Rba.LogFunctions.ps1")
. (Join-Path ([System.IO.Path]::GetDirectoryName($MyInvocation.MyCommand.Definition)) "Microsoft.Rba.CoreHelper.ps1")
