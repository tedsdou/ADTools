﻿function Get-RbaDnsDynamicUpdate
{
	<#
	.SYNOPSIS
   		Get-RbaDnsDynamicUpdate is a Powershell function that gets a DNS zone Dynamic Update status.
	.DESCRIPTION
   		Get-RbaDnsDynamicUpdate is a Powershell function that gets a DNS zone Dynamic Update status.
	.PARAMETER DomainController
		Performs the operation on a specific Domain controller, must be FQDN.
	.PARAMETER Domain
		Performs the operation on any domain controller of the specified domain, query is performed on a single domain controller only.
	.PARAMETER DNSZoneName
		String representation of a DNS zone. E.g. contoso.com.
	.EXAMPLE
		Gets dynamic updates status for Contoso.com DNS Zone from first available domain controller.

		Get-RbaDnsDynamicUpdate -Domain "Contoso.com" -DNSZoneName "Contoso.com"
	.EXAMPLE
		Gets dynamic updates status for Contoso.com DNS Zone on a user specified domain controller.

		Get-RbaDnsDynamicUpdate -DomainController "DC01.contoso.com" -DNSZoneName "Contoso.com"
	.RETURNS
		PSObject list with following attributes:
			DomainControllerName
			DNSZoneName
			DynamicUpdate
			DistinguishedName
	.NOTES
		Must be executed on a domain with a domain admin account.
		Get information about Primary zones only.
	#>
	[CmdletBinding()]
	param
	(                                
 		[parameter(Mandatory=$true, ParameterSetName="UsingDCName")]
		[string]$DomainController,

 		[parameter(Mandatory=$true, ParameterSetName="UsingDomainName")]
		[string]$Domain,

 		[parameter(Mandatory=$false)]
		[string]$DNSZoneName
	)

	begin
	{
		# Setting up environment
		$ErrorActionPreference = [System.Management.Automation.ActionPreference]::Stop

		Set-StrictMode -Version 2.0
		
		#if (!(Test-RbaSupportedEnv -MinSupportedOSVersion 6.2))
		if (!(Test-RbaSupportedEnv))
		{
			$UnsupportedEnvMessage | Add-RbaLogEntry -Severity ([Severity]::Error) -NoConsoleOutput
			throw ($UnsupportedEnvMessage)
		}	
	}
	
	process
	{
		try
		{
			"Deciding how to get a DC object" | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
			# Deciding how to get a DC object
			if ($PSCmdlet.ParameterSetName -eq "UsingDomainName")
			{
				$dc = (Get-RbaADDomainController -Scope Domain -ScopeValue $Domain)[0]
			}
			else
			{
				$dc = (Get-RbaADDomainController -Scope Computer -ScopeValue $DomainController)[0]
			}
			
			"Using DC $($dc.name) " | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
			"Creating DNS PS object " | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
			# Creating DNS PS object
			$zones = Get-WmiObject -Class MicrosoftDNS_Zone -Namespace "root\MicrosoftDNS" -ComputerName $dc.dnsHostName

			if ($zones -ne $null)
			{
                $result = @()
				foreach ($zone in $zones)
				{
					# Only interested on Primary zones
					if ($zone.ZoneType -ieq 1)
					{
						"Zone type is Primary - $($zone.ZoneType)" | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
						$includeInResult = $true

						# Verifying if current zone should be included into result array

						if ( !([string]::IsNullOrEmpty($DNSZoneName)) -and !($DNSZoneName -ieq $zone.Name))
						{
							$includeInResult = $false
						}

						if ($includeInResult -and !($zone.Name -ieq "TrustAnchors"))
						{
							"Working on zone $($zone.Name)"  | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
							
							# Creating empty object
							$dnsZone = New-RbaObject -Property @{	"DomainControllerName"=[string]::empty;
																	"DNSZoneName"=[string]::empty;
																	"DynamicUpdate"=[string]::empty;
																	"DistinguishedName"=[string]::empty}

							$dnsZone.DomainControllerName=$dc.Name
							$dnsZone.DNSZoneName=$zone.Name
							$dnsZone.DynamicUpdate = (ConvertAllowUpdateValueToString -AllowUpdateValue $zone.AllowUpdate)

							$dnsDN = GetDNSDistinguishedName -DomainController $dc.Name -DNSZoneName $zone.Name
							if ($dnsDN -ne $null)
							{
								$dnsZone.DistinguishedName=$dnsDN
							}
							
							"Zone info included in results: DC Name=$($dnsZone.DomainControllerName) - ZoneName=$($dnsZone.DNSZoneName) - DynamicUpdate=$($dnsZone.DynamicUpdate) - DN=$($dnsZone.DistinguishedName) " | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput 

							$result += $dnsZone
						}
					}
				}
			}
		}
		catch
		{
            "An error ocurred trying to query dns zone dynamic update type." | Log-ErrorToFile -Error $_
		    Write-Error "An error ocurred trying to query dns zone dynamic update type. Error details: $_"	
		}
	}

	end
	{
		"End of Script" | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput 
		return ,$result
	}
}

#------------------------------------------------
# Dot sourcing internal functions used by cmdlets
#------------------------------------------------
. (Join-Path ([System.IO.Path]::GetDirectoryName($MyInvocation.MyCommand.Definition)) "Microsoft.Rba.LogFunctions.ps1")
. (Join-Path ([System.IO.Path]::GetDirectoryName($MyInvocation.MyCommand.Definition)) "Microsoft.Rba.CoreHelper.ps1")
