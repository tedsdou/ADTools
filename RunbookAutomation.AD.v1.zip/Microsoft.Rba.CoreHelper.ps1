﻿<#
.SYNOPSIS
   Microsoft.RaasAD.Rba.CoreHelper.psm1 - This module contains generic functions that can be consumed on all other modules/functions and gathers all export functions to pass to PSD1 file.
.DESCRIPTION
   Microsoft.RaasAD.Rba.CoreHelper.psm1 - This module contains generic functions that can be consumed on all other modules/functions and gathers all export functions to pass to PSD1 file.
#>
. (Join-Path ([System.IO.Path]::GetDirectoryName($MyInvocation.MyCommand.Definition)) "Microsoft.Rba.LogFunctions.ps1")

Set-StrictMode -Version 2.0

$ErrorActionPreference = [System.Management.Automation.ActionPreference]::Stop

$enumScopeDef = @"
public enum QueryScope
{	
	Domain,
	Computer,
	User
}
"@
try { Add-Type -TypeDefinition $enumScopeDef } catch {}

$enumFilterTypeDef = @"
public enum FilterType
{	
	LDAP,
	Powershell
}
"@
try { Add-Type -TypeDefinition $enumFilterTypeDef } catch {}

$UnsupportedEnvMessage = @"
Unsupported environment for Runbook Automation, please make sure you are using this module on Windows 2008 R2 or greater with Powershell 3.0 or greater.
Please refer to the links below to install Powershell 4.0 on a Windows 7/2008 R2 machine.
Microsoft .NET Framework 4.5.1 (Offline Installer)
http://www.microsoft.com/en-us/download/details.aspx?id=40779 
Windows Management Framework 4.0
http://www.microsoft.com/en-us/download/details.aspx?id=40855
"@

function Get-RbaComputerHostName
{
	<#
	.SYNOPSIS
	   	Gets the hostname from FQDN
	.DESCRIPTION
	   	Gets the hostname from FQDN
	.PARAMETER FQDN
		Computer FQDN
	.EXAMPLE
		Get-RbaComputerHostName -FQDN "DC01.Contoso.com"
	#>
	[CmdletBinding()]
	param
	(
		[Parameter(Mandatory=$true)]
		[ValidateNotNullOrEmpty()]
		[string] $FQDN
	)
	
	return $FQDN.Split(".")[0]
	
}

function New-RbaObject
{
	<#
	.SYNOPSIS
	   	This function is used to create Powershell Object with its properties while PS 2.0 is still supported, if PS 3.0 is used we can use hash tables to define properties easily instead.
	.DESCRIPTION
	   	This function is used to create Powershell Object with its properties while PS 2.0 is still supported, if PS 3.0 is used we can use hash tables to define properties easily instead.
	.PARAMETER Property
		Hash table with property name a value
	.EXAMPLE
		New-RbaObject -Property @{'Name' = 'TestString'}
	#>
	[CmdletBinding()]
	param
	(
		[Parameter(Mandatory=$true)]
		[ValidateNotNullOrEmpty()]
		[Hashtable]$Property
	)

	$psObject = New-Object PSObject

	foreach ($key in $Property.Keys)
	{
		if (($Property[$key].GetType()).Name -eq "ResultPropertyValueCollection")
		{
			if ($Property[$key].count -gt 1)
			{
				$value= @()
				foreach ($item in $Property[$key])
				{
					$value += $item
				}
			}
			else
			{
				$value=$Property[$key][0]		
			}
		}
		else
		{
			$value = $Property[$key]
		}

		$psObject | Add-Member -Type NoteProperty -Name $key -Value $value
	}

	return $psObject
}

function Test-RbaSupportedEnv
{
	<#
	.SYNOPSIS
	   	This function is used to test if environment where Runbook Automation for AD is supported.
	.DESCRIPTION
	   	This function is used to test if environment where Runbook Automation for AD is supported.
	.PARAMETER
		MinSupportedOSVersion - Version object stating minimum OS version supported (e.g. [Version]"6.1" = Windows 2008 R2)
	.PARAMETER
		Detail - Returns detailed supported version and test result
	.RETURNS
		Boolean - false if environment is not supported
		PSObject - returns test result details if -Detail is used
	.EXAMPLE
		Test-RbaSupportedEnv
	#>
	[CmdletBinding()]
	param
	(
		
		[Parameter(Mandatory=$false)]
		[Version]$MinSupportedOSVersion=[Version]"6.0",
		
		[Parameter(Mandatory=$false)]
		[Switch]$Detail
	)

	$osVersion = ([Environment]::OSVersion).Version
	$psVersion = ($PSVersionTable).PSVersion

	$currentlySupportedOSVersion = $MinSupportedOSVersion
	$currentlySupportedPSVersion = [Version]"2.0"

	if ($Detail)
	{
		$osVersionItem = New-RbaObject -Property @{	"Name"="OSVersion";
													"Value"=$osVersion;
													"Supported"=($osVersion -ge $currentlySupportedOSVersion) }
		
		$psVersionItem = New-RbaObject -Property @{	"Name"="PSVersion";
													"Value"=$psVersion;
													"Supported"=($psVersion -ge $currentlySupportedPSVersion) }
														
		return @($osVersionItem,$psVersionItem)
	}	
	else
	{
		return (($osVersion -ge $currentlySupportedOSVersion) -and ($psVersion -ge $currentlySupportedPSVersion))
	}
}

function Get-RbaAvgPingResponseTime
{
	[CmdletBinding()]
	param
	(
		[Parameter(Mandatory=$true)]
		[String]$ComputerName,

		[Parameter(Mandatory=$true)]
		[int]$PingTestCount = 2
	)

	$connDetail = Test-Connection -ComputerName $ComputerName -Count $PingTestCount -ErrorAction SilentlyContinue -BufferSize 1 -TimeToLive 1
				
	[int]$responseTimeSum = -1
	foreach ($cn in $connDetail)
	{
        if ($cn -ne $null)
        {
            if ($responseTimeSum -lt 0)
            {
                $responseTimeSum = 0
            }
       	    $responseTimeSum += $cn.ResponseTime
        }
	}

	return $responseTimeSum / $PingTestCount
}

function Get-RbaBestPingRankedDomainController
{
	<#
	.SYNOPSIS
	   	Get-RbaBestPingRankedDomainController is a function that returns one domain controller that is reachable through ping per domain in a forest, chosen from lower response time
	.DESCRIPTION
	   	Get-RbaBestPingRankedDomainController is a function that returns one domain controller that is reachable through ping per domain in a forest, chosen from lower response time
	#>
	[CmdletBinding()]
	param
	(
		[Parameter(Mandatory=$true, ParameterSetName="Domain")]
		[String]$Domain,

		[Parameter(Mandatory=$true, ParameterSetName="Forest")]
		[Switch]$Forest,

		[Parameter(Mandatory=$false, ParameterSetName="Forest")]
		[Parameter(Mandatory=$false, ParameterSetName="Domain")]
		[Switch]$All
	)
	
	$adForest = [system.directoryservices.activedirectory.Forest]::GetCurrentForest()
    $sortedDCList = @()
    
    switch ($PSCmdlet.ParameterSetName)
    {
        "Forest"
        {
			foreach ($domain in $adForest.Domains)
			{
				$domainControllers = @()
				$domainDCList = @()

                if ($domain.PSObject.Properties['Name'] -ne $null)
                {
                    $domainLDAP = ConvertFqdnToLdapPath -DomainFQDN $domain.Name
                }
                else
                {
                    $domainLDAP = ConvertFqdnToLdapPath -DomainFQDN $domain
                }

				$domainControllers = GetRbaADObject -LDAPFilter "(userAccountControl:1.2.840.113556.1.4.803:=8192)" -SearchRoot $domainLDAP -SearchScope ([System.DirectoryServices.SearchScope]::SubTree)
				
				if ($domainControllers -ne $null)
				{
					foreach ($dc in $domainControllers)
					{
						$AvgResponseTime = Get-RbaAvgPingResponseTime -ComputerName $dc.dnsHostname -PingTestCount 2
						
						if ($AvgResponseTime -ge 0)
						{
							$dc | Add-Member -MemberType NoteProperty -Name "AvgResponseTime" -Value $AvgResponseTime -Force
							$domainDCList += $dc
						}
					}

					if ($domainDCList -ne $null)
					{
						if (!($All))
						{
							$sortedDCList += (,$domainDCList | Sort-Object -Property AvgResponseTime)[0]
						}
						else
						{
							$sortedDCList += $domainDCList | Sort-Object -Property AvgResponseTime
						}
					}
				}
			}
			break		
		}
		
		"Domain"
		{
			$domainControllers = @()
			$domainDCList = @()
			$domainLDAP = ConvertFqdnToLdapPath -DomainFQDN $Domain
			$domainControllers = GetRbaADObject -LDAPFilter "(userAccountControl:1.2.840.113556.1.4.803:=8192)" -SearchRoot $domainLDAP -SearchScope ([System.DirectoryServices.SearchScope]::SubTree)

			if ($domainControllers -ne $null)
			{
				foreach ($dc in $domainControllers)
				{
					$AvgResponseTime = Get-RbaAvgPingResponseTime -ComputerName $dc.dnsHostname -PingTestCount 2
						
					if ($AvgResponseTime -ge 0)
					{
						$dc | Add-Member -MemberType NoteProperty -Name "AvgResponseTime" -Value $AvgResponseTime -Force
						$domainDCList += $dc
					}
				}

				if ($domainDCList -ne $null)
				{
					if (!($All))
					{
						$sortedDCList += (,$domainDCList | Sort-Object -Property AvgResponseTime)[0]
					}
					else
					{
						$sortedDCList += $domainDCList | Sort-Object -Property AvgResponseTime
					}
				}
			}
		}
	}
	return ,$sortedDCList
}

function Get-RbaADDomainController
{
	<#
	.SYNOPSIS
	   	Get-RbaADDomainController - Retrieves Active Directory domain controller objects as PSObjects given a scope (DomainController, Domain or Forest)
	.DESCRIPTION
	   	Get-RbaADDomainController - Retrieves Active Directory domain controller objects as PSObjects given a scope (DomainController, Domain or Forest)
	.PARAMETER 
		Scope - QueryScope enumeration that is used to query domain or forest wide objects
	.PARAMETER
		ScopeValue - String that represents the domain or computer name
	.PARAMETER
		Forest - Switch that enables forest search scope
	.RETURNS
		PSObjects
	.EXAMPLE
	#>
	[CmdletBinding()]
	param
	(
		[Parameter(Mandatory=$true, ParameterSetName="NonForest")]
		[QueryScope]$Scope,

		[Parameter(Mandatory=$true, ParameterSetName="NonForest")]
		[String]$ScopeValue,

		[Parameter(Mandatory=$true, ParameterSetName="Forest")]
		[Switch]$Forest,

		[Parameter(Mandatory=$true, ParameterSetName="SingleCurrentDomain")]
		[Switch]$SingleCurrentDomain,
		
		[Parameter(Mandatory=$true, ParameterSetName="AllCurrentDomain")]
		[Switch]$AllCurrentDomain

	)

    $adForest = [system.directoryservices.activedirectory.Forest]::GetCurrentForest()
    $objectList = @()

	switch ($PSCmdlet.ParameterSetName)
	{
		"Forest"
		{
			"[ForestScope] Retrieving DCs from forest" | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
			$domains = $ADforest.domains 
			foreach ($dom in $domains)
			{
				try
				{
					"[ForestScope] Retrieving DCs from domain $($dom.Name)" | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
					$domainLDAP = ConvertFqdnToLdapPath -DomainFQDN $dom.Name
					$objectList += GetRbaADObject -LDAPFilter "(userAccountControl:1.2.840.113556.1.4.803:=8192)" -SearchRoot $domainLDAP -SearchScope ([System.DirectoryServices.SearchScope]::SubTree)
				}
				catch
				{
					"[ForestScope] Error retrieving DCs for: $($dom.Name)." | Log-ErrorToFile -Error $_
					Write-Error "Error retrieving DCs for: $($dom.Name)`n$($_.Exception.Message)" -ErrorAction Continue
				}
			}		
			break;
		}
		"NonForest"
		{
			if ($Scope -eq ([QueryScope]::User))
			{
				"[UserScope] Invalid QueryScope for this function, valid QueryScopes are Domain and Computer" | Add-RbaLogEntry -Severity ([Severity]::Error) -NoConsoleOutput
				throw "Invalid QueryScope for this function, valid QueryScopes are Domain and Computer"
			}

			switch ($Scope)
			{
				([QueryScope]::Domain)
				{
					"[DomainScope] Retrieving DCs from domain: $ScopeValue" | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
			
					$domainLDAP = ConvertFqdnToLdapPath -DomainFQDN $ScopeValue
					$objectList += GetRbaADObject -LDAPFilter "(userAccountControl:1.2.840.113556.1.4.803:=8192)" -SearchRoot $domainLDAP -SearchScope ([System.DirectoryServices.SearchScope]::SubTree)

					if ($objectList.Count -eq 0)
					{
						Write-Error "[DomainScope] Error retrieving DCs for: $ScopeValue"
					}
					break
				}
				([QueryScope]::Computer)
				{
					"[ComputerScope] Retrieving DC: $ScopeValue" | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput

					if ($ScopeValue.Contains("."))
					{
						$domainFQDN = $ScopeValue.Substring($ScopeValue.IndexOf(".")+1)
						"[ComputerScope] Domain FQDN, sent by computer FQDN ==> $domainFQDN" | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
					}
					else
					{
						$domainFQDN = ([System.Net.NetworkInformation.IPGlobalProperties]::GetIPGlobalProperties()).DomainName
						"[ComputerScope] Domain FQDN, queried by [System.Net.NetworkInformation.IPGlobalProperties]::GetIPGlobalProperties() ==> $domainFQDN " | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
					}

					$domainLDAP = ConvertFqdnToLdapPath -DomainFQDN $domainFQDN
					"[ComputerScope] Domain LDAP ==> $domainLDAP " | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
					$objectList += GetRbaADObject -LDAPFilter "(&(userAccountControl:1.2.840.113556.1.4.803:=8192)(|(dnsHostname=$ScopeValue)(name=$ScopeValue)))" -SearchRoot $domainLDAP -SearchScope ([System.DirectoryServices.SearchScope]::SubTree)
				}
			}
			break;
		}
		"SingleCurrentDomain"
		{
			$currentDomain = [system.directoryservices.activedirectory.domain]::GetCurrentDomain()
			$objectList = Get-RbaBestPingRankedDomainController -Domain $currentDomain.Name
			
			break;
		}
		"AllCurrentDomain"
		{
			$currentDomain = [system.directoryservices.activedirectory.domain]::GetCurrentDomain()
			$objectList = Get-RbaBestPingRankedDomainController -Domain $currentDomain.Name -All 
			
			break;
		}
	}
	
    return ,$objectList
}

function GetRbaADObject
{
	[CmdletBinding()]
	param
	(
		[Parameter(Mandatory=$false)]
		[String]$DomainController,
		
		[Parameter(Mandatory=$false)]
		[String]$DomainFQDN,

		[Parameter(Mandatory=$true, ParameterSetName="LDAPFilter")]
		[String]$LDAPFilter,

		[Parameter(Mandatory=$true, ParameterSetName="Identity")]
		[String]$Identity,

		[Parameter(Mandatory=$false, ParameterSetName="LDAPFilter")]
		[String]$SearchRoot,

		[Parameter(Mandatory=$false, ParameterSetName="LDAPFilter")]
		[System.DirectoryServices.SearchScope]$SearchScope = [System.DirectoryServices.SearchScope]::Base,

		[Parameter(Mandatory=$false)]
		[string[]]$Property
	)

	# Checking if domain controller as a query target should be used
	"Checking if domain controller as a query target should be used" | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
	if (!([string]::IsNullOrEmpty($DomainController)))
	{
		$adsInitialPath = [string]::Format("LDAP://{0}", $DomainController)
	}
	else
	{
		$adsInitialPath = "LDAP:/"
	}

	"ADSPath that will be used $adsInitialPath" | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput

	#using current domain by default
	if ([string]::IsNullOrEmpty($DomainFQDN))
	{
		$currentDomain = ConvertFqdnToLdapPath -DomainFQDN ([system.directoryservices.activedirectory.domain]::GetCurrentDomain())
	}
	else
	{
		$currentDomain = ConvertFqdnToLdapPath -DomainFQDN $DomainFQDN
	}
	
	$adsPath = [string]::Format("{0}/{1}",$adsInitialPath,$currentDomain)
	"ADSPath with current domain by default => $adsPath" | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput

	# Configuring DirectorySearcher object
	$searcher = New-Object System.DirectoryServices.DirectorySearcher
	$searcher.PageSize = 1000
	$searcher.ServerTimeLimit = New-Object System.TimeSpan(0, 0, 30)
	$searcher.ClientTimeout = New-Object System.TimeSpan(0, 10, 0)

	# Adding properties if specified
	if ($Property -ne $null)
	{
		"Adding property to query $Property" | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
		$searcher.PropertiesToLoad.AddRange($Property)
	}
    
	# Checking if query should use LDAP Filter or direct object through DN of the object
	if ($PSCmdlet.ParameterSetName -eq "LDAPFilter")
	{
		"Using LDAPFilter parameterset " | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
		"   Search scope $SearchScope" | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
		$searcher.SearchScope = $SearchScope
		# Checking if a Search Root was passed, if not, current domain is used as defaut value
		if (!([string]::IsNullOrEmpty($SearchRoot)))
		{
			if ($SearchRoot.Contains("."))
			{
				throw "SearchRoot parameter cannot be FQDN value, please use ConvertFqdnToLdapPath function to convert it to a LDAP notation. Current SearchRoot value is $SearchRoot"
			}

			$adsPath =  [string]::Format("{0}/{1}",$adsInitialPath,$SearchRoot)
		}
		"   New ADSPath $adsPath" | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
		
		if (!([string]::IsNullOrEmpty($LDAPFilter)))
		{
			"   Using LDAP Filter => $LDAPFilter" | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
			$searcher.Filter = $LDAPFilter	
		}

		$searcher.SearchRoot = New-Object System.DirectoryServices.DirectoryEntry($adsPath)
	}
	elseif ($PSCmdlet.ParameterSetName -eq "Identity")
	{
		"Using Identity parameterset " | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
		"   Searchroot => $([string]::Format("{0}/{1}",$adsInitialPath,$Identity))" | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
		$searcher.SearchScope = [System.DirectoryServices.SearchScope]::Base
		$searcher.SearchRoot = New-Object System.DirectoryServices.DirectoryEntry([string]::Format("{0}/{1}",$adsInitialPath,$Identity))
	}

	# Converting SearcherResult objects to PSObjects
	$searcher.PageSize = 1000
	$searcher.ReferralChasing = [System.DirectoryServices.ReferralChasingOption]::All
	$searcher.ClientTimeout = 120
	$searcher.ServerTimeLimit = 120
	$results = @()

	foreach ($result in $searcher.FindAll())
	{
		$results += New-RbaObject -Property $result.properties
	}

	return $results
}

function Set-RbaADObject
{
	[CmdletBinding()]
	param
	(
		[Parameter(Mandatory=$true)]
		[ValidateNotNullOrEmpty()]
		[String]$Identity,
		
		[Parameter(Mandatory=$true,ParameterSetName="Replace")]
		[ValidateNotNullOrEmpty()]
		[Hashtable]$Replace,

		[Parameter(Mandatory=$false)]
		[String]$DomainController
	)

	if ([string]::IsNullOrEmpty($DomainController))
	{
		$aDSPath = [string]::Format("LDAP://{0}",$Identity)
	}
	else
	{
		$aDSPath = [string]::Format("LDAP://{0}/{1}",$DomainController,$Identity)
	}

	"ADSPath= $aDSPath" | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput

	switch ($PSCmdlet.ParameterSetName)
	{
		"Replace"
		{
			$adObj = [ADSI] $aDSPath
			"   ADOBJ=$($adObj.Name)" | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
			
			if ($adObj -ne $null)
			{ 
				foreach ($key in $Replace.Keys)
				{
					"   KEY=$key" | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
					"   VALUE=$($Replace[$key])" | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
					 $adObj.PSBase.InvokeSet($key,$Replace[$key]) 
				}
				$adObj.setinfo()  
			}
			break;
		}
	}
}

function Get-RbaADObject
{
	<#
	.SYNOPSIS
	   	Get-RbaADObject - Retrieves Active Directory objects as PSObjects given a scope (Computer, Domain or Forest)
	.DESCRIPTION
	   	Get-RbaADObject - Retrieves Active Directory objects as PSObjects given a scope (Computer, Domain or Forest)
	.PARAMETER 
		Scope - QueryScope enumeration that is used to query domain or forest wide objects
	.PARAMETER
		ScopeValue - String that represents the domain or computer name
	.PARAMETER
		Forest - Switch that enables forest search scope
	.PARAMETER
		Property - String array with property names to be retrieved
	.PARAMETER
		LDAPFilter - string that represents a LDAP filter. E.g. "(&(objectCategory=computer)(!userAccountControl:1.2.840.113556.1.4.803:=8192))"
	.RETURNS
		PSObjects
	.EXAMPLE
		Getting all computer accounts from forest and requesting useraccountcontrol property.

		Get-RbaADObject -Forest -Property "useraccountcontrol" | ft
	.EXAMPLE
		Getting all computer accounts, except domain controllers (by using LDAP filtering capability), from forest and requesting useraccountcontrol property.

		Get-RbaADObject -Forest -Property "useraccountcontrol" -LDAPFilter "(&(objectCategory=computer)(!userAccountControl:1.2.840.113556.1.4.803:=8192))" | ft
	.EXAMPLE
		Getting all computer accounts, except domain controllers (by using LDAP filtering capability), from a specified domain controller and requesting useraccountcontrol property.

		Get-RbaADObject -Scope Computer -ScopeValue "dc01" -Property "useraccountcontrol" -LDAPFilter "(&(objectCategory=computer)(!userAccountControl:1.2.840.113556.1.4.803:=8192))" | ft
	.EXAMPLE
		Getting all computer accounts from a specified domain controller and requesting useraccountcontrol property.

		Get-RbaADObject -Scope Computer -ScopeValue "dc01" -Property "useraccountcontrol" | ft 
	.EXAMPLE
		Getting all computer accounts from a specified domain and requesting useraccountcontrol property.

		Get-RbaADObject -Scope Domain -ScopeValue contoso.com -Property "useraccountcontrol" | ft
	.EXAMPLE
		Getting all computer accounts, except domain controllers (by using LDAP filtering capability), from a specified domain and requesting useraccountcontrol property.

		Get-RbaADObject -Scope Domain -ScopeValue contoso.com -Property "useraccountcontrol" -LDAPFilter "(&(objectCategory=computer)(!userAccountControl:1.2.840.113556.1.4.803:=8192))" | ft
	.EXAMPLE
		Returns computer objects filtered by a bitwise AND operation after all objects are retrieved from a domain controller

		(Get-RbaADObject -Forest -Property distinguishedname,UserAccountControl) | ? { $_.UserAccountControl -band 4194304 }
	#>
	[CmdletBinding()]
	param
	(
		[Parameter(Mandatory=$true, ParameterSetName="NonForest")]
		[QueryScope]$Scope,

		[Parameter(Mandatory=$true, ParameterSetName="NonForest")]
		[String]$ScopeValue,

		[Parameter(Mandatory=$true, ParameterSetName="Forest")]
		[Switch]$Forest,

		[Parameter(Mandatory=$false)]
		[string[]]$Property,

		[Parameter(Mandatory=$true)]
		[string]$LDAPFilter
	)

	if ($Property -eq $null)
	{
		$Property = "*"
	}

	$SearchScope = [System.DirectoryServices.SearchScope]::Subtree

    $objectList = @()

	if ($PSCmdlet.ParameterSetName -eq "Forest")
	{
		"[ForestScope] Retrieving a list of one responding DC per forest" | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
		$dcList = Get-RbaBestPingRankedDomainController -Forest 
		"[ForestScope] DC List Count: $($dcList.Count)" | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput

		if ($dcList -eq $null)
		{
			"[ForestScope] Error retrieving domain controller list from forest" | Add-RbaLogEntry -Severity ([Severity]::Error) -NoConsoleOutput
			throw "Error retrieving domain controller list from forest"
		}

		# Iterating over DC list to obtain object list
		foreach ($dc in $dcList)
		{
			$searchRoot = $dc.DistinguishedName.ToString().Substring($dc.DistinguishedName.IndexOf("DC="))
			$objectList += GetRbaADObject -LDAPFilter $LDAPFilter -DomainController $dc.Name -Property $Property -SearchRoot $searchRoot -SearchScope ($SearchScope)
		}
	}
	else
	{
		if ($Scope -eq ([QueryScope]::User))
		{
			"Invalid QueryScope for this function, valid QueryScopes are Domain and Computer" | Add-RbaLogEntry -Severity ([Severity]::Error) -NoConsoleOutput
			throw "Invalid QueryScope for this function, valid QueryScopes are Domain and Computer"
		}

		switch ($Scope)
		{
			([QueryScope]::Domain)
			{
				"Retrieving best ping ranking DC from domain $ScopeValue" | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
				$dc = Get-RbaBestPingRankedDomainController -Domain $ScopeValue
				
				if ($dc -eq $null)
				{
					"Error retrieving domain controller list from domain $ScopeValue" | Add-RbaLogEntry -Severity ([Severity]::Error) -NoConsoleOutput
					throw "Error retrieving domain controller list from domain $ScopeValue"
				}
				
				$searchRoot = $dc[0].DistinguishedName.ToString().Substring($dc[0].DistinguishedName.IndexOf("DC="))
				$objectList += GetRbaADObject -LDAPFilter $LDAPFilter -DomainController $dc[0].Name -Property $Property -SearchRoot $searchRoot -SearchScope ($SearchScope)
	
				break
			}
			([QueryScope]::Computer)
			{
				$dc = Get-RbaADDomainController -Scope ([QueryScope]::Computer) -ScopeValue $ScopeValue
				if ($dc -ne $null)
				{
					$searchRoot = $dc[0].DistinguishedName.ToString().Substring($dc[0].DistinguishedName.IndexOf("DC="))
					$objectList += GetRbaADObject -LDAPFilter $LDAPFilter -DomainController $dc[0].Name -Property $Property -SearchRoot $searchRoot -SearchScope ($SearchScope)
				}
				
				break
			}
		}
	}
	
    return ,$objectList
}

function Remove-RbaSingleDontRequirePreAuth
{
	<#
	.SYNOPSIS
   		Remove-RbaDontRequirePreAuth is an internal function that removes the Don't Require Kerberos Pre-Authentication option from an object
	.DESCRIPTION
		Remove-RbaDontRequirePreAuth is an internal function that removes the Don't Require Kerberos Pre-Authentication option from an object
	.PARAMETER DistinguishedName
		Distinguished name of an object to remove the DONT_REQUIRE_PREAUTH flag from userAccountControl object property
	.EXAMPLE
		Remove-RbaSingleDontRequirePreAuth -DistinguishedName "CN=CONSOLE,CN=Computers,DC=Contoso,DC=com"
	.NOTE
		This cmdlet needs domain admin credentials of current domain or enterprise admin if logged on domain controller is not the same as the user account.
	#>
	[CmdletBinding(SupportsShouldProcess=$true,ConfirmImpact="High")]
	param
	(                                
 		[Parameter(Mandatory=$true, ValueFromPipeline=$false)]
		[string]$DistinguishedName,

		[Parameter(Mandatory=$false)]
		[string]$DomainController
	)

	#Constants
	Set-Variable DONT_REQUIRE_PREAUTH -Option Constant -Value 4194304

	if ([string]::IsNullOrEmpty($DomainController))
	{
		$domainName = $DistinguishedName.ToUpper().Substring($DistinguishedName.ToUpper().IndexOf("DC=")+3, $DistinguishedName.Length - ($DistinguishedName.ToUpper().IndexOf("DC=")+3)).Replace(",DC=",".") 
		$DomainController = (Get-RbaADDomainController -Scope Domain -ScopeValue $domainName)[0].Name
	}
	
	# Get object using its distinguished name
	Write-Verbose "Searching for object: $DistinguishedName"
	$object = GetRbaADObject -Identity $DistinguishedName -Property DistinguishedName, userAccountControl, Name -DomainController $DomainController

	# Removing option for Don't Require Pre Auth
	Write-Verbose "Removing `"Don`'t Require Pre Authentication`" user account control option"
	if ($object -ne $null)
	{
		if ($PSCmdlet.ShouldProcess($DistinguishedName))
		{
			$newUserAccountControl = $object.userAccountControl -bxor $DONT_REQUIRE_PREAUTH
			
			Set-RbaADObject -Identity $object.DistinguishedName -Replace @{userAccountControl=$newUserAccountControl} -DomainController $DomainController
		}
	}
	else
	{
		Write-Host "Object DN $DistinguishedName didn't return any object"
	}
}

function CheckNTDSConfig
{
	<# 
		Helper function, used to check the configuration of nTDSDSA object(s)
		Takes two parameters:
			option - value of nTDSDSA option attribute (mandatory)
			DomainController - FQDN of a domain controller (optional). If not specified, forest wide search is performed.
	#>
    param
	(
        [Parameter(Mandatory=$true,Position=0)]
		[string]$option,

        [Parameter(Mandatory=$false,Position=1)]
		[string]$DomainController
    )

    $nTDSDSAs = @()

    $configurationNamingContext = (New-Object DirectoryServices.DirectoryEntry("LDAP://RootDSE")).configurationNamingContext

	$sourceDomainController = (Get-RbaADDomainController -Scope ([QueryScope]::Computer) -ScopeValue $env:COMPUTERNAME)[0]

	"Source DC for queries $sourceDomainController.Name" | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
	
    if (!([string]::IsNullOrEmpty($DomainController)))
    {
		"DomainController $DomainController specified" | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
		$nTDSDSAs += GetNTDSAObject -DomainController $DomainController
    }
    else
    {
		"DomainController parameter was not specified - getting all DCs NTDSAs" | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
		$nTDSDSAs += GetNTDSAObject
    }
    
	if ($nTDSDSAs -ne $null)
	{
		$i = 0
		foreach ($nTDSDSA in $nTDSDSAs)
		{
			"Checking NTDS configuration for $($nTDSDSA.distinguishedName)" | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
			$dcDn = $nTDSDSA.distinguishedName.Split(",",2)[1]

			"dcDN: $dcDN " | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
			$hostName = (GetRbaADObject -Identity $dcDn -Property dNSHostName -DomainController $sourceDomainController.Name).dNSHostName

			"Hostname: $hostName" | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
			Write-Progress -Activity "Configuration check in progress..." -Status $hostName -PercentComplete (($i++ / $nTDSDSAs.Count) * 100)

			try
			{
				$options = (GetRbaADObject -Identity $nTDSDSA.DistinguishedName -Property options -DomainController $sourceDomainController.Name).options
				if ($options -band $option)
				{
					$hostName
				}
			}
			catch
			{
				"Exception on $hostName." | Log-ErrorToFile -Error $_
				Write-Error "Exception on $hostName`n$_" -ErrorAction "Continue"
			}
		}
	}
	else
	{
		"No nTDSA objects found." | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
	}
}

function ConvertAllowUpdateValueToString
{
	param
	(
        [Parameter(Mandatory=$true)] [int]$AllowUpdateValue
    )

	$returnValue = $null

	switch ($AllowUpdateValue)
	{
		0
		{
			$returnValue="None"
			break;
		}
		1
		{
			$returnValue="NonsecureAndSecure"
			break;
		}
		2
		{
			$returnValue="SecureOnly"
			break;
		}
	}
	
	return $returnValue
}

function GetNameContextList
{
	param
	(
		[Switch]$ExcludeConfigAndSchema
    )

	$rootDSE = New-Object DirectoryServices.DirectoryEntry("LDAP://RootDSE")

	if ($ExcludeConfigAndSchema)
	{
		return ,($rootDSE.NamingContexts | ? {-Not ($_.ToString().ToLower().Contains("schema") -or $_.ToString().ToLower().Contains("configuration"))})
	}
	else
	{
		return ,($rootDSE.NamingContexts)
	}

}

function GetDNSDistinguishedName
{
	<# 
		Works currently on current logged on domain
	#>
	param
	(
		[Parameter(Mandatory=$true)]
		[String]$DomainController,
		
		[Parameter(Mandatory=$true)]
		[string]$DNSZoneName
	)

	$dnsDNList = @()
	foreach ($namecontext in (GetNameContextList -ExcludeConfigAndSchema))
	{
		$dnsDN = GetRbaADObject -LDAPFilter "(&(objectCategory=dnsZone)(name=$DNSZoneName))" -DomainController $DomainController -Property distinguishedName -SearchRoot $namecontext -SearchScope ([System.DirectoryServices.SearchScope]::Subtree)
        if ($dnsDN -ne $null)
        {
            $dnsDNList += $dnsDN
        }
	}

	if ($dnsDNList.Count -gt 1)
	{
		throw "Duplicate DNS Zones found, this cmdlet cannot continue. Zone name $DNSZoneName was found $($dnsDNList.Count) times"
	}
	elseif ($dnsDNList.Count -eq 0)
	{
		throw "DNS Zone not found, this cmdlet cannot continue. Zone name $DNSZoneName was not found."
	}

	return $dnsDNList[0].DistinguishedName
}

function ConvertFqdnToLdapPath
{
	param
	(
		[Parameter(Mandatory=$true)]
		[string]$DomainFQDN
	)

	return [string]::Format("DC={0}",$DomainFQDN.Replace(".",",DC="))
}

function CheckRegistryDSANotWritableValue
{
	param
	(
		[Parameter(Mandatory=$true)]
		[String]$DomainControllerName
	)

    # connects to the remote registry of a $DC and checks for the "DSA not writable" registry key
    Write-Verbose "Checking registry on $DomainControllerName"
    $reg = $null
    try
    {
        $reg = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey("LocalMachine", $DomainControllerName)
    }
    catch
    {
		"Error opening remote registry on $DomainControllerName`n$($_.Exception.Message)"| Add-RbaLogEntry -Severity ([Severity]::Error)
        return
    }
    $regKey = $reg.OpenSubKey("System\CurrentControlSet\Services\NTDS\Parameters")
    $val = $regKey.GetValue("DSA not writable")

    $status = ""
    switch ($val)
    {
        1 {$status = "The forest version is incompatible with the OS"; break}
        2 {$status = "No sufficient free disk space"; break}
        4 {$status = "USN rollback"; break}
        8 {$status = "Up-to-dateness-vector is corrupted"; break}
    }

	$result = $null
    if ($status -ne "")
    {
		$result = New-RbaObject @{ "DomainController" = $DomainControllerName; "Status" = $status; "Value"=$val }
    }

    $regKey.Close()
    $reg.Close()

	return $result
}

function Exists
{
	param
    (
        $List,
        $Item
    )

	foreach ($obj in $List)
	{
		if ($obj -eq $Item)
		{
			return $true
		}
	}

	return $false
}

function GetNTDSAObject
{
	param
	(
        [Parameter(Mandatory=$false)]
		[string]$DomainController
    )
	$nTDSDSAs = @()
    $configurationNamingContext = (New-Object DirectoryServices.DirectoryEntry("LDAP://RootDSE")).configurationNamingContext
	$sourceDomainController = (Get-RbaADDomainController -Scope ([QueryScope]::Computer) -ScopeValue $env:COMPUTERNAME)[0]

    if (!([string]::IsNullOrEmpty($DomainController)))
    {
		#"Getting information for specific DC $DomainController" | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
		$dc = GetRbaADObject -LDAPFilter "(|(dNSHostName=$DomainController)(name=$DomainController))" -Property DistinguishedName -SearchRoot $configurationNamingContext -SearchScope ([System.DirectoryServices.SearchScope]::SubTree) -DomainController $sourceDomainController.Name
        if ($dc -ne $null)
		{
			$nTDSDSAs += GetRbaADObject -Identity "CN=NTDS Settings,$($dc.distinguishedName)" -DomainController $sourceDomainController.Name
		}
    }
    else
    {
		#"DomainController parameter was not specified - performing forest wide search" | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
		$nTDSDSAs += GetRbaADObject -LDAPFilter "(objectCategory=CN=NTDS-DSA,CN=Schema,$configurationNamingContext)" -SearchRoot $configurationNamingContext -SearchScope ([System.DirectoryServices.SearchScope]::SubTree) -DomainController $sourceDomainController.Name
    }

	return ,$nTDSDSAs
}

function Convert-MetadataToHashTable
{
	param
	(
        [Parameter(Mandatory=$true)]
		$Metadata
    )

	$returnHashTable = @{}

	foreach ($metadataLine in $Metadata)
	{
		$xml = New-Object XML
		$xml.LoadXml($metadataLine)

		$key = $xml.DS_REPL_ATTR_META_DATA.pszAttributeName
		$item = New-RbaObject @{"pszAttributeName"=$key;
								"dwVersion"=$xml.DS_REPL_ATTR_META_DATA.dwVersion;
								"ftimeLastOriginatingChange"=$xml.DS_REPL_ATTR_META_DATA.ftimeLastOriginatingChange;
								"uuidLastOriginatingDsaInvocationID"=$xml.DS_REPL_ATTR_META_DATA.uuidLastOriginatingDsaInvocationID;
								"usnOriginatingChange"=$xml.DS_REPL_ATTR_META_DATA.usnOriginatingChange;
								"usnLocalChange"=$xml.DS_REPL_ATTR_META_DATA.usnLocalChange;
								"pszLastOriginatingDsaDN"=$xml.DS_REPL_ATTR_META_DATA.usnLocalChange;
						}
		$returnHashTable.Add($key,$item)
	}
	return ,$returnHashTable
}

function Get-DNSSuffixFromDCName
{
	param
	(
        [Parameter(Mandatory=$true)]
		$DnsHostName
    )

	return $DnsHostName.Substring($DnsHostName.indexof(".")+1)
}

function GetAllItemsExcept
{
	param
	(
		[string]$excludedItem,
		$array
	)

	$returnList = @()

	foreach ($item in $array)
	{
		if ($item -ne $excludedItem)
		{
			$returnList += $item
		}
	}

	return ,$returnList
}

#-------------------------------------------------------------
# Exporting all functions including ones from nested modules
#-------------------------------------------------------------
#Export-ModuleMember -Function '*'

#------------------------------------------------
# Variables to export
#------------------------------------------------
#Export-ModuleMember -Variable 'UnsupportedEnvMessage'
