﻿function Set-RbaTombstoneLifetime
{
	<#
	.SYNOPSIS
   		Set-RbaTombstoneLifetime is a Powershell function that set forest tombstone lifetime.
	.DESCRIPTION
   		Set-RbaTombstoneLifetime is a Powershell function that set forest tombstone lifetime.
	.PARAMETER NewTombstoneLifetime
		New Tombstone Lifetime by day. Default is 180 day.
	.EXAMPLE
		Set tombstone lifetime of forest.

		Set-RbaTombstoneLifetime -NewTombstoneLifetime 180
	.NOTES
		It requires Root Domain Administrator priviledge. 
        It requires PS version 2.0, 3.0, or 4.0.
		
	#>
    [CmdletBinding(SupportsShouldProcess=$true, ConfirmImpact="High")]
	param
	(                                
 		[Parameter(Mandatory=$true)]
		[int]$NewTombstoneLifetime
	)
    
    #---------------------------------------
	# Preparing process
	#---------------------------------------
    begin
	{
		# Setting up environment
		Set-StrictMode -Version 2.0
		
		if (!(Test-RbaSupportedEnv))
		{
			$UnsupportedEnvMessage | Add-RbaLogEntry -Severity ([Severity]::Error) -NoConsoleOutput
			throw ($UnsupportedEnvMessage)
		}	
		$ErrorActionPreference = [System.Management.Automation.ActionPreference]::Stop
	}

    #---------------------------------------
	# Main function process
	#---------------------------------------
    Process
    {
	    try
	    {
			if ($NewTombstoneLifetime -lt 60)
		    {
				"Tombstone lifetime is too small." | Add-RbaLogEntry -Severity ([Severity]::Error) -NoConsoleOutput
			    throw ("Tombstone lifetime is too small.")
		    }

            if($PSCmdlet.ShouldProcess("Set forest tombstone lifetime."))
	        {
                # Get Forest Configuration Naming Context
				"Getting Forest Configuration Naming Context..." | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput

				$configurationNamingContext = (New-Object DirectoryServices.DirectoryEntry("LDAP://RootDSE")).configurationNamingContext

                # Set new tomstone lifetime for the forest
				"Setting new tombstone lifetime for the forest..." | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
				Set-RbaADObject -Identity "CN=Directory Service,CN=Windows NT,CN=Services,$configurationNamingContext" -Replace @{tombstonelifetime = $NewTombstoneLifetime}
            }
	    }
	    catch
	    {
			"An error ocurred trying to change Tombstone Lifetime." | Log-ErrorToFile -Error $_
		    Write-Error "An error ocurred trying to change Tombstone Lifetime. Error details: $_" 
	    }
    }

	end
	{
		"End of Script" | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
	}
}

#------------------------------------------------
# Dot sourcing internal functions used by cmdlets
#------------------------------------------------
. (Join-Path ([System.IO.Path]::GetDirectoryName($MyInvocation.MyCommand.Definition)) "Microsoft.Rba.LogFunctions.ps1")
. (Join-Path ([System.IO.Path]::GetDirectoryName($MyInvocation.MyCommand.Definition)) "Microsoft.Rba.CoreHelper.ps1")
