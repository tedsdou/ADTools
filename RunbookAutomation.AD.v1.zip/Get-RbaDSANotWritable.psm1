function Get-RbaDSANotWritable
{
	<#
	.SYNOPSIS
   		Get-RbaDSANotWritable is a Powershell function that returns a list of domain controllers that have "DSA not writable" registry key set.
	.DESCRIPTION
   		Get-RbaDSANotWritable is a Powershell function that returns a list of domain controllers that have "DSA not writable" registry key set.
		This function performs forest wide search or checks a domain that was specified.
	.PARAMETER Domain
		Domain FQDN.
	.PARAMETER Forest
		Forest FQDN.
	.EXAMPLE
        Get-RbaDSANotWritable

        Performs forest wide search for a domain controllers with "DSA not writable" registry key set.
	.EXAMPLE
		Get-RbaDSANotWritable -Domain contoso.com

        Performs domain wide search for a domain controllers with "DSA not writable" registry key set.
	.NOTES
		Must be executed with an enterprise admin account.
    .OUTPUTS
        PSObject
        Get-RbaDSANotWritable returns objects that represent domain controllers with "DSA not writable" registry key set.
	#>

	[CmdletBinding(SupportsShouldProcess=$true, ConfirmImpact="High")]
	param
	(
		[Parameter(ParameterSetName="Domain", Mandatory=$true, ValueFromPipeline=$false)]
		[string]$Domain,

		[Parameter(ParameterSetName="Forest", Mandatory=$false)]
        [switch]$Forest
	)

	# Setting up environment
	Set-StrictMode -Version 2.0
		
	if (!(Test-RbaSupportedEnv))
	{
		throw ($UnsupportedEnvMessage)
	}	

	$ErrorActionPreference = "Stop"

    # Affected computer list
    $outputList = @()
	$dcList = @()

	if ($PSCmdlet.ParameterSetName -eq "Forest")
	{
		"Using Forest search..." | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
		$dcList  += Get-RbaADDomainController -Forest
	}
	else
	{
		"Using Domain search..." | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
		$dcList += Get-RbaADDomainController -Scope ([QueryScope]::Domain) -ScopeValue $Domain 
	}

    foreach ($domaiController in $dcList)
    {
        Write-Progress -Activity "Working..." -Status "Checking registry on $($domaiController.Name)"
		$dc =  CheckRegistryDSANotWritableValue -DomainControllerName $domaiController.Name
		if ($dc -ne $null)
		{
			$outputList += $dc
		}
    }
    return ,$outputList
}

#------------------------------------------------
# Dot sourcing internal functions used by cmdlets
#------------------------------------------------
. (Join-Path ([System.IO.Path]::GetDirectoryName($MyInvocation.MyCommand.Definition)) "Microsoft.Rba.LogFunctions.ps1")
. (Join-Path ([System.IO.Path]::GetDirectoryName($MyInvocation.MyCommand.Definition)) "Microsoft.Rba.CoreHelper.ps1")