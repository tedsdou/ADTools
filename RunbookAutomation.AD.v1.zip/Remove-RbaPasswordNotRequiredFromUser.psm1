﻿function Remove-RbaPasswordNotRequiredFromUser
{
	<#
	.SYNOPSIS
   		Remove-RbaPasswordNotRequiredFromUser is a Powershell function that removes password not required flag from user account.
	.DESCRIPTION
   		Remove-RbaPasswordNotRequiredFromUser is a Powershell function that removes password not required flag from user account. Cmdlet works with the results returned by Get-RbaUserWithPasswordNotRequired cmdlet.
    .PARAMETER UserDN
        User distinguished name (can be returned from Get-RbaUserWithPasswordNotRequired, see examples).
	.EXAMPLE
        (Get-RbaUserWithPasswordNotRequired -UserName JanK) | % { $_.DistinguishedName } | Remove-RbaPasswordNotRequiredFromUser

        Removes password not required flag from user accounts returned by Get-RbaUserWithPasswordNotRequired cmdlet.
	.EXAMPLE
		Remove-RbaPasswordNotRequiredFromUser -UserDN "CN=Jank,CN=User,DC=contoso,DC=com"

		Removes password not required flag from user account based on its distinguishedName.
	.NOTES
		Must be executed with an enterprise admin account.
	#>
	[CmdletBinding(SupportsShouldProcess=$true,ConfirmImpact="High")]
	param
	(
		[Parameter(Mandatory=$true, ValueFromPipeline=$true)]
		[String]$UserDN
	)

    begin
    {
    	# Setting up environment
	    Set-StrictMode -Version 2.0
		
    	if (!(Test-RbaSupportedEnv))
	    {
			$UnsupportedEnvMessage | Add-RbaLogEntry -Severity ([Severity]::Error) -NoConsoleOutput
		    throw ($UnsupportedEnvMessage)
	    }	

	    $ErrorActionPreference = "Stop"

    	# Constants
	    Set-Variable PASSWD_NOTREQD -option Constant -value 32
    }
    process
    {
        foreach ($user in $UserDN)
        {
            "Removing PASSWD_NOTREQD flag from the $user." | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
			try
			{
				$domainName = $user.ToUpper().Substring($user.ToUpper().IndexOf("DC=")+3, $user.Length - ($user.ToUpper().IndexOf("DC=")+3)).Replace(",DC=",".") 
				$dcObj = (Get-RbaADDomainController -Scope Domain -ScopeValue $domainName)[0]

				$userObject = GetRbaADObject -Identity $user -DomainController $dcObj.Name -Property name,userAccountControl
	            
				$userAccountControl = $userObject.userAccountControl
		        $userAccountControl = $userAccountControl -bxor $PASSWD_NOTREQD
			    
				if ($PSCmdlet.ShouldProcess($user, "Removing PASSWD_NOTREQD flag"))
				{
					Set-RbaADObject -Identity $user -Replace @{"userAccountControl"=$userAccountControl} -DomainController $dcObj.Name
				}
			}
			catch
			{
				"There was an error processing user $user." | Log-ErrorToFile -Error $_
				Write-Error "There was an error processing user $user`n$($_.Exception.Message)" -ErrorAction Continue
			}
        }
    }
}

#------------------------------------------------
# Dot sourcing internal functions used by cmdlets
#------------------------------------------------
. (Join-Path ([System.IO.Path]::GetDirectoryName($MyInvocation.MyCommand.Definition)) "Microsoft.Rba.LogFunctions.ps1")
. (Join-Path ([System.IO.Path]::GetDirectoryName($MyInvocation.MyCommand.Definition)) "Microsoft.Rba.CoreHelper.ps1")
