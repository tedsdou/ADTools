﻿function Get-RbaUserWithPasswordNotRequired
{
	<#
	.SYNOPSIS
   		Get-RbaUserWithPasswordNotRequired is a Powershell function that returns a list of users with password not required flag set.
	.DESCRIPTION
   		Get-RbaUserWithPasswordNotRequired is a Powershell function that returns a list of users with password not required flag set.
	.PARAMETER Domain
		Domain name specified as a FQDN when using -Domain parameter set.
    .PARAMETER UserName
        sAMAccountName of a user.
    .PARAMETER UserDomain
        Specifies domain FQDN when using -UserName parameter set.
    .PARAMETER Forest
        Search forest wide scope.
	.EXAMPLE
        Get-RbaUserWithPasswordNotRequired

        Performs forest wide search for a users with password not required flag set.
	.EXAMPLE
		Get-RbaUserWithPasswordNotRequired -Domain contoso.com

        Gets the list of users with password not required flag set searching a specific domain.
	.EXAMPLE
		Get-RbaUserWithPasswordNotRequired -UserName JanK

        Checks the status of password not required flag set on a specific user. Returns $null if the flag is not set.
	.NOTES
		Must be executed with an enterprise admin account.
    .OUTPUTS
        PSObject
        Get-RbaUserWithPasswordNotRequired returns objects that represent users with password not required flag set.
	#>
	[CmdletBinding(SupportsShouldProcess=$true, ConfirmImpact="High", DefaultParameterSetName="Forest")]
	param
	(
		[Parameter(ParameterSetName="User", Mandatory=$true, ValueFromPipeline=$false)]
		[string]$UserName,

		[Parameter(ParameterSetName="User", Mandatory=$false, ValueFromPipeline=$false)]
		[string]$UserDomain,
	
		[Parameter(ParameterSetName="Domain", Mandatory=$true, ValueFromPipeline=$false)]
		[string]$Domain,

		[Parameter(ParameterSetName="Forest", Mandatory=$false)]
        [switch]$Forest
	)

	# Setting up environment
	Set-StrictMode -Version 2.0
		
	if (!(Test-RbaSupportedEnv))
	{
		$UnsupportedEnvMessage | Add-RbaLogEntry -Severity ([Severity]::Error) -NoConsoleOutput
		throw ($UnsupportedEnvMessage)
	}	

	$ErrorActionPreference = "Stop"

	# Constants
	Set-Variable PASSWD_NOTREQD -option Constant -value 32
    Set-Variable INTERDOMAIN_TRUST_ACCOUNT -Option Constant -Value 2048

    # Affected computer list
    $outputList = @()

    switch ($PSCmdlet.ParameterSetName)
    {
        "User"
            {
                "Checking properties of $UserName user..." | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
				try
				{
					if ([string]::IsNullOrEmpty($UserDomain))
		            {
						$UserDomain = ([system.directoryservices.activedirectory.domain]::GetCurrentDomain()).Name
					}
					
					$context = New-Object System.DirectoryServices.ActiveDirectory.DirectoryContext("Domain",$UserDomain)
					$domainObj = [system.directoryservices.activedirectory.domain]::GetDomain($context)

					$dcObj = (Get-RbaADDomainController -Scope Domain -ScopeValue $UserDomain)[0]
					
					if ($dcObj-ne $null)
					{
						$res = GetRbaADObject -LDAPFilter "(&(objectCategory=person)(objectClass=user)(sAMAccountName=$UserName)(userAccountControl:1.2.840.113556.1.4.803:=$PASSWD_NOTREQD))" -DomainController $dcObj.Name -Property distinguishedName, userAccountControl -SearchRoot ($domainObj.GetDirectoryEntry()).DistinguishedName -SearchScope ([System.DirectoryServices.SearchScope]::Subtree)
						if ($res -ne $null)
						{
							$res | Add-Member -MemberType NoteProperty -Name "Domain" -Value $UserDomain -Force
							$outputList += $res
						}
					}
				}
				catch
				{
					"There was an error retrieving data for user $UserName." | Log-ErrorToFile -Error $_
                    Write-Error "There was an error retrieving data for user $UserName`n$($_.Exception.Message)" -ErrorAction Continue
				}
                break
            }
        "Domain"
            {
                "Retrieving list of users with PASSWD_NOTREQD from domain $Domain..." | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
                Write-Progress -Activity "Working..." -Status "Retrieving list of users with PASSWD_NOTREQD from domain $Domain..."
				try
				{
					$context = New-Object System.DirectoryServices.ActiveDirectory.DirectoryContext("Domain",$Domain)
					$domainObj = [system.directoryservices.activedirectory.domain]::GetDomain($context)
					$dcObj = (Get-RbaADDomainController -Scope Domain -ScopeValue $Domain)[0]
					
					if ($dcObj-ne $null)
					{
						$res = GetRbaADObject -LDAPFilter "(&(objectCategory=person)(objectClass=user)(userAccountControl:1.2.840.113556.1.4.803:=$PASSWD_NOTREQD)(!(userAccountControl:1.2.840.113556.1.4.803:=$INTERDOMAIN_TRUST_ACCOUNT)))" -DomainController $dcObj.Name -Property distinguishedName, userAccountControl -SearchRoot ($domainObj.GetDirectoryEntry()).DistinguishedName -SearchScope ([System.DirectoryServices.SearchScope]::Subtree)
						if ($res -ne $null)
						{
							$res | Add-Member -MemberType NoteProperty -Name "Domain" -Value $Domain -Force
							$outputList += $res
						}
					}
				}
				catch
				{
					"There was an error retrieving data from domain $Domain." | Log-ErrorToFile -Error $_
                    Write-Error "There was an error retrieving data from domain $Domain`n$($_.Exception.Message)" -ErrorAction Continue
				}
                break
            }
        "Forest"
            {
				$domains = ([system.directoryservices.activedirectory.Forest]::GetCurrentForest()).Domains
                foreach ($dom in $domains)
                {
                    "Retrieving list of users with PASSWD_NOTREQD from domain $($dom.Name)..." | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
                    Write-Progress -Activity "Working..." -Status "Retrieving list of users with PASSWD_NOTREQD from domain $($dom.Name)..."
                    try 
                    {
						$context = New-Object System.DirectoryServices.ActiveDirectory.DirectoryContext("Domain",$dom.Name)
						$domainObj = [system.directoryservices.activedirectory.domain]::GetDomain($context)
						$dcObj = (Get-RbaADDomainController -Scope Domain -ScopeValue $dom.Name)[0]
					
						if ($dcObj-ne $null)
						{
							$res = GetRbaADObject -LDAPFilter "(&(objectCategory=person)(objectClass=user)(userAccountControl:1.2.840.113556.1.4.803:=$PASSWD_NOTREQD)(!(userAccountControl:1.2.840.113556.1.4.803:=$INTERDOMAIN_TRUST_ACCOUNT)))" -DomainController $dcObj.Name -Property distinguishedName, userAccountControl -SearchRoot ($domainObj.GetDirectoryEntry()).DistinguishedName -SearchScope ([System.DirectoryServices.SearchScope]::Subtree)
							if ($res -ne $null)
							{
								$res | Add-Member -MemberType NoteProperty -Name "Domain" -Value $dom.Name -Force
								$outputList += $res
							}
						}
                    }
                    catch
                    {
						"There was an error retrieving data from domain $dom." | Log-ErrorToFile -Error $_
                        Write-Error "There was an error retrieving data from domain $dom`n$($_.Exception.Message)" -ErrorAction Continue
                    }
                }
                break
            }
    }
    return ,$outputList
}

#------------------------------------------------
# Dot sourcing internal functions used by cmdlets
#------------------------------------------------
. (Join-Path ([System.IO.Path]::GetDirectoryName($MyInvocation.MyCommand.Definition)) "Microsoft.Rba.LogFunctions.ps1")
. (Join-Path ([System.IO.Path]::GetDirectoryName($MyInvocation.MyCommand.Definition)) "Microsoft.Rba.CoreHelper.ps1")
