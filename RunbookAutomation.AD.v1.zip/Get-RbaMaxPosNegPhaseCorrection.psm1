function Get-RbaMaxPosNegPhaseCorrection
{
	<#
	.SYNOPSIS
   		Get-RbaMaxPosNegPhaseCorrection is a Powershell function that gets MaxPosPhaseCorrection and MaxNegPhaseCorrection values from a domain controller.
	.DESCRIPTION
   		Get-RbaMaxPosNegPhaseCorrection is a Powershell function that gets MaxPosPhaseCorrection and MaxNegPhaseCorrection values from a domain controller.
    .PARAMETER DomainController
		DomainController, has to be FQDN or Computer Name.
	.PARAMETER MaxPosPhaseCorrectionTime
		New MaxPosPhaseCorrection value by second.
    .PARAMETER MaxNegPhaseCorrectionTime
		New MaxNegPhaseCorrection value by second.
	.EXAMPLE
		Get-RbaMaxPosNegPhaseCorrection -DomainController LocalComputerName

	.NOTES
        It requires PS version 2.0, 3.0, or 4.0.
		
	#>
    [CmdletBinding(SupportsShouldProcess=$true, ConfirmImpact="High")]
	param
	( 
        [Parameter(Mandatory=$true)]
		[array]$DomainController
	)

    #---------------------------------------
	# Preparing process
	#---------------------------------------
    begin
	{
		# Setting up environment
		Set-StrictMode -Version 2.0
		
		if (!(Test-RbaSupportedEnv))
		{
			$UnsupportedEnvMessage | Add-RbaLogEntry -Severity ([Severity]::Error) -NoConsoleOutput
			throw ($UnsupportedEnvMessage)
		}	
		
		$ErrorActionPreference = [System.Management.Automation.ActionPreference]::Stop
		$returnList = @()
	}
	
    #---------------------------------------
	# Main function process
	#---------------------------------------
    Process
    {
	    try
	    {
            
            foreach($computerName in $DomainController)
            {
				"Connecting $computerName remote registry..." | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
                $reg=[Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey('LocalMachine', $computerName)

				"Openning SubKey SYSTEM\CurrentControlSet\services\W32Time\config ..." | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
                $key=$reg.OpenSubKey('SYSTEM\CurrentControlSet\services\W32Time\config', $false)

				try
				{
					"Getting MaxPosPhaseCorrection..." | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
					$posValue = $key.GetValue('MaxPosPhaseCorrection')
				}
				catch
				{
					"An error ocurred trying to get MaxPosPhaseCorrection registry value." | Log-ErrorToFile -Error $_
					$posValue = 0
				}
				
				try
				{
					"Getting MaxNegPhaseCorrection..." | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
					$negValue = $key.GetValue('MaxNegPhaseCorrection')
				}
				catch
				{
					"An error ocurred trying to get MaxNegPhaseCorrection registry value." | Log-ErrorToFile -Error $_
					$negValue = 0
				}
				    
				"Closing $key..." | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
                $key.Close()

                "Closing $reg..." | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
                $reg.Close()

				$returnList += New-RbaObject -Property @{'DomainController'=$computerName;
													'MaxPosPhaseCorrection'=$posValue;
													'MaxNegPhaseCorrection'=$negValue}
				
            }
            
	    }
	    catch
	    {
			"An error ocurred trying to change MaxPosPhaseCorrection or  MaxNegPhaseCorrection." | Log-ErrorToFile -Error $_
		    Write-Error "An error ocurred trying to change MaxPosPhaseCorrection or  MaxNegPhaseCorrection. Error details: $_"	
	    }
    }

	end
	{
		,$returnList
		"End of Script" | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
	}
}

#------------------------------------------------
# Dot sourcing internal functions used by cmdlets
#------------------------------------------------
. (Join-Path ([System.IO.Path]::GetDirectoryName($MyInvocation.MyCommand.Definition)) "Microsoft.Rba.LogFunctions.ps1")
. (Join-Path ([System.IO.Path]::GetDirectoryName($MyInvocation.MyCommand.Definition)) "Microsoft.Rba.CoreHelper.ps1")
