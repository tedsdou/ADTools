function Backup-RbaDomainController
{
	<#
	.SYNOPSIS
   		Backup-RbaDomainController is a Powershell function that start system state backup of local computer to network path or local volume.
	.DESCRIPTION
   		Backup-RbaDomainController is a Powershell function that start system state backup of local computer to network path or local volume.
	.PARAMETER NetworkPath
		NetworkPath, has to be valid network path.
    .PARAMETER LocalVolume
		LocalVolume, has to be valid local volume path.It is can not be system drive (c:).
	.EXAMPLE
		Start backup of the local domain controller to a specific network path.

		Backup-RbaDomainController -NetworkPath \\remotePC\share
	.EXAMPLE
		Start backup of the local domain controller to a local volume path.

		Backup-RbaDomainController -LocalVolume E:
	.NOTES
		Must be executed at least with a member of backup operators group.
        It requires PS version 2.0, 3.0, or 4.0.
	#>
    [CmdletBinding(SupportsShouldProcess=$true, ConfirmImpact="Medium")]
	param
	(                                
 		[Parameter(Mandatory=$true, ParameterSetName= "NetworkPath")]
		[string]$NetworkPath,
        [Parameter(Mandatory=$true, ParameterSetName= "LocalVolume")]
		[string]$LocalVolume
	)

    #---------------------------------------
	# Preparing process
	#---------------------------------------
    begin
	{
		# Setting up environment
		Set-StrictMode -Version 2.0
		
	    if (!(Test-RbaSupportedEnv -MinSupportedOSVersion 6.1))
		{
			$UnsupportedEnvMessage | Add-RbaLogEntry -Severity ([Severity]::Error) -NoConsoleOutput
			throw ($UnsupportedEnvMessage)
		}		
		
		$ErrorActionPreference = [System.Management.Automation.ActionPreference]::Stop
        
        if ($PSCmdlet.ShouldProcess("Windows Backup Feature"))
	    {

		    if ($Host.Version.Major -eq 2) 
		    {

				if( (Get-Module ServerManager) -eq $null)
				{   
					"Importing ServerManager Module..." | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
					try 
					{
						Import-Module Servermanager -Verbose:$false
					}
					catch
					{
						"Server Manager does not exists, please install Server Manager." | Add-RbaLogEntry -Severity ([Severity]::Error) -NoConsoleOutput
						Write-Error "Server Manager does not exists, please install Server Manager."
					}
				}
			   
                if((Get-WindowsFeature Backup-Features).Installed -eq $false)
                {
					"Installing Windows Backup Feature..." | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
                    Add-WindowsFeature Backup-Features -Includeallsubfeature -Verbose:$false
                }

                if((Get-PSSnapin Windows.Serverbackup -ErrorAction SilentlyContinue) -eq $null)
                {
					"Adding Pssnapin Windows.Serverbackup..." | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
                    Add-Pssnapin Windows.Serverbackup -Verbose:$false
                }

		    }
		    else
		    {
                if((Get-WindowsFeature Windows-Server-Backup).Installed -eq $false)
                {
					"Installing Windows Backup Feature..." | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
			        Add-WindowsFeature Windows-Server-Backup -Includeallsubfeature -Verbose:$false
                }
		    }
	    }
	}

    #---------------------------------------
	# Main function process
	#---------------------------------------
    Process
    {
        try
	    {
            #Create New Backup Policy
			"Creating New Backup Policy..." | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
            $policy = New-WBpolicy

            #Add system state backup
		    "Adding system state to backup..." | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
            Add-WBsystemstate -Policy $policy

            # Decide the backup target place
            if ($PSCmdlet.ParameterSetName -eq "NetworkPath")
            {
                #Check the backup folder target location
				"Checking the backup target folder..." | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
		        $backupLocation = Test-Path -Path $NetworkPath
        
		        if (!($backupLocation))
				{
					"Network path $NetworkPath does not exists, please enter a valid path." | Add-RbaLogEntry -Severity ([Severity]::Error) -NoConsoleOutput
                    throw "Network path $NetworkPath does not exists, please enter a valid path."
                }

                #Set backup target network path
		        "Setting backup target network path..." | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
                $backupTargetNetwork=New-WBbackupTarget -NetworkPath $NetworkPath
                Add-WBBackupTarget -Policy $policy -Target $backupTargetNetwork
                
            }
            else
            {
                #Check the backup folder target local volume
                "Checking the backup target local volume..." | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
		        $backupLocation = Test-Path -Path $LocalVolume
        
		        if (!($backupLocation))
				{
					"Local volume $LocalVolume does not exists, please enter a valid volume." | Add-RbaLogEntry -Severity ([Severity]::Error) -NoConsoleOutput
                    throw "Local volume $LocalVolume does not exists, please enter a valid volume."
                }

                if ( (Get-WBVolume -VolumePath $LocalVolume).property.toString() -match "Critical" )
				{
				   "$LocalVolume is a critical volume. It can not be backup target." | Add-RbaLogEntry -Severity ([Severity]::Error) -NoConsoleOutput
                   throw "$LocalVolume is a critical volume. It can not be backup target."
                }

                #Set backup target local volume
		        "Setting backup target local volume..." | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
                $backupTargetLocal=New-WBbackupTarget -VolumePath $LocalVolume
                Add-WBBackupTarget -Policy $policy -Target $backupTargetLocal  
            }
        
            #Start backup policy
			"Starting backup..." | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
            Start-WBBackup -Policy $Policy
	    }
	    catch
	    {
			"An error ocurred trying to backup DC" | Log-ErrorToFile -Error $_
		    Write-Error "An error ocurred trying to backup DC. Error details: $_"	
	    }
    }
	end
	{
		"End of Script" | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput 
	}
}

#------------------------------------------------
# Dot sourcing internal functions used by cmdlets
#------------------------------------------------
. (Join-Path ([System.IO.Path]::GetDirectoryName($MyInvocation.MyCommand.Definition)) "Microsoft.Rba.LogFunctions.ps1")
. (Join-Path ([System.IO.Path]::GetDirectoryName($MyInvocation.MyCommand.Definition)) "Microsoft.Rba.CoreHelper.ps1")