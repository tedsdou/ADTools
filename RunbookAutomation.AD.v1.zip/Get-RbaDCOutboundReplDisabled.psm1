function Get-RbaDCOutboundReplDisabled
{
	<#
	.SYNOPSIS
   		Get-RbaDCOutboundReplDisabled is a Powershell function that returns a list of domain controllers that have outbound replication disabled.
	.DESCRIPTION
   		Get-RbaDCOutboundReplDisabled is a Powershell function that returns a list of domain controllers that have outbound replication disabled.
		This function performs forest wide search or checks a DC based on a parameter that was specified.
	.PARAMETER DomainController
		Domain controller name specified as a FQDN.
	.EXAMPLE
        Get-RbaDCOutboundReplDisabled

        Performs forest wide search for a domain controllers with outbound replication disabled.
	.EXAMPLE
		Get-RbaDCOutboundReplDisabled -DomainController DC01.contoso.com

        Checks if outbound replication is disabled on DC01.contoso.com domain controller.
	.NOTES
		Must be executed with an enterprise admin account.
    .OUTPUTS
        System.String
        Get-RbaDCOutboundReplDisabled returns objects that represent domain controllers with outbound replication disabled.
	#>

    [CmdletBinding()]
    param
	(
		[Parameter(Mandatory=$false,Position=0)]
		[string]$DomainController
	)

	# Setting up environment
	$ErrorActionPreference = [System.Management.Automation.ActionPreference]::Stop

	Set-StrictMode -Version 2.0
		
	if (!(Test-RbaSupportedEnv))
	{
		$UnsupportedEnvMessage | Add-RbaLogEntry -Severity ([Severity]::Error) -NoConsoleOutput
		throw ($UnsupportedEnvMessage)
	}	

    Set-Variable -Name DISABLE_OUTBOUND_REPL -Value 4 -Option Constant

	if (!([string]::IsNullOrEmpty($DomainController)))
    {
        CheckNTDSConfig -option $DISABLE_OUTBOUND_REPL -DomainController $DomainController
    }
    else
    {
        CheckNTDSConfig -option $DISABLE_OUTBOUND_REPL
    }   
}

#------------------------------------------------
# Dot sourcing internal functions used by cmdlets
#------------------------------------------------
. (Join-Path ([System.IO.Path]::GetDirectoryName($MyInvocation.MyCommand.Definition)) "Microsoft.Rba.LogFunctions.ps1")
. (Join-Path ([System.IO.Path]::GetDirectoryName($MyInvocation.MyCommand.Definition)) "Microsoft.Rba.CoreHelper.ps1")
