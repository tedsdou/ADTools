﻿function Get-RbaComputerKerberosPreAuthDisabled
{
	<#
	.SYNOPSIS
   		Get-RbaComputerKerberosPreAuthDisabled is a Powershell function that gets a list of AD Computer objects that have Kerberos Pre-Authentication disabled.
	.DESCRIPTION
   		Get-RbaComputerKerberosPreAuthDisabled is a Powershell function that gets a list of AD Computer objects that have Kerberos Pre-Authentication disabled.
	.PARAMETER
		Domain - String representing domain FQDN to query a specific domain.
	.PARAMETER
		Forest - Switch parameter indicating that query must be performed on all domains within current forest.
	.EXAMPLE
		Look up for Kerberos Pre-Authentication disabled computer accounts on Contoso.com domain.

		Get-RbaComputerKerberosPreAuthDisabled -Domain Contoso.com
	.EXAMPLE
		Look up for Kerberos Pre-Authentication disabled computer accounts on the current forest.

		Get-RbaComputerKerberosPreAuthDisabled -Forest
	.NOTES
		Must be executed on each domain with a domain admin account.
	.RETURNS
		Microsoft.ActiveDirectory.Management.ADComputer
	#>
	[CmdletBinding()]
	param
	(
		[Parameter(ParameterSetName="Domain", Mandatory=$true, ValueFromPipeline=$false)]
		[string]$Domain,

		[Parameter(ParameterSetName="Forest", Mandatory=$false)]
        [switch]$Forest
	)

	begin
	{
		# Setting up environment
		$ErrorActionPreference = [System.Management.Automation.ActionPreference]::Stop

		Set-StrictMode -Version 2.0
		
		if (!(Test-RbaSupportedEnv))
		{
			$UnsupportedEnvMessage | Add-RbaLogEntry -Severity ([Severity]::Error) -NoConsoleOutput
			throw ($UnsupportedEnvMessage)
		}	
		
		#Constants
		Set-Variable DONT_REQUIRE_PREAUTH -Option Constant -Value 4194304
	}

	process
	{
		try
		{
			# Obtaining computer list
			"Querying Active Directory for computer accounts that have Kerberos Pre Authentication disabled..." | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
			$computers = @()

			if ($PSCmdlet.ParameterSetName -eq "Forest")
			{
				$computers  += Get-RbaADObject -Forest -LDAPFilter "(&(objectCategory=computer)(userAccountControl:1.2.840.113556.1.4.803:=$DONT_REQUIRE_PREAUTH))" -Property UserAccountControl, DistinguishedName
			}
			else
			{
				$computers  += Get-RbaADObject -Scope Domain -ScopeValue $Domain -LDAPFilter "(&(objectCategory=computer)(userAccountControl:1.2.840.113556.1.4.803:=$DONT_REQUIRE_PREAUTH))" -Property UserAccountControl, DistinguishedName
			}
		}
		catch
		{
			"An error occurred querying AD objects." | Log-ErrorToFile -Error $_
		}
	}

	end 
	{
		"Returned objects count $($computers.Count)" | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
		"End of Script" | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput 
		# Returning affected objects
		return ,$computers
	}
}

#------------------------------------------------
# Dot sourcing internal functions used by cmdlets
#------------------------------------------------
. (Join-Path ([System.IO.Path]::GetDirectoryName($MyInvocation.MyCommand.Definition)) "Microsoft.Rba.LogFunctions.ps1")
. (Join-Path ([System.IO.Path]::GetDirectoryName($MyInvocation.MyCommand.Definition)) "Microsoft.Rba.CoreHelper.ps1")
