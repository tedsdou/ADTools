﻿function Set-RbaDnsDynamicUpdate
{
	<#
	.SYNOPSIS
   		Set-RbaDnsDynamicUpdate is a Powershell function that changes a DNS zone Dynamic Update setting.
	.DESCRIPTION
   		Set-RbaDnsDynamicUpdate is a Powershell function that changes a DNS zone Dynamic Update setting.
		It will accept following values: None, Secure and NonsecureAndSecure
	.PARAMETER DomainController
		Performs the operation on a specific Domain controller, must FQDN.
	.PARAMETER Domain
		Performs the operation on any domain controller of the specified domain, changed is performed on a single domain controller only.
	.PARAMETER DNSZoneName
		String representation of a DNS zone. E.g. contoso.com
	.PARAMETER DynamicUpdate
		How dynamic update will be configured, valid values are: None, Secure and NonsecureAndSecure.
	.EXAMPLE
		Sets dynamic updates to secure only for Contoso.com DNS Zone. And this cmdlet will choose one domain controller to perform this change.

		Set-RbaDnsDynamicUpdate -Domain "Contoso.com" -DNSZoneName "Contoso.com" -DynamicUpdate Secure
	.EXAMPLE
		Sets dynamic updates to secure only for Contoso.com DNS Zone on a user specified domain controller.

		Set-RbaDnsDynamicUpdate -DomainController "DC01.contoso.com" -DNSZoneName "Contoso.com" -DynamicUpdate Secure
	.RETURNS
		PSObject list with following attributes:
			DomainControllerName
			DNSZoneName
			DynamicUpdateSettingName
			DynamicUpdateSettingValue
	.NOTES
		Must be executed on a domain with a domain admin account.
	#>
	[CmdletBinding(SupportsShouldProcess=$true,ConfirmImpact="High")]
	param
	(                                
 		[parameter(Mandatory=$true, ParameterSetName="UsingDCName")]
		[string]$DomainController,

 		[parameter(Mandatory=$true, ParameterSetName="UsingDomainName")]
		[string]$Domain,

 		[parameter(Mandatory=$true)]
		[string]$DNSZoneName,
		
		[parameter(Mandatory=$true)]
		[validateSet("None","SecureOnly","NonSecureAndSecure",IgnoreCase=$true)]
		[string]$DynamicUpdate
	)

	begin
	{
		# Setting up environment
		Set-StrictMode -Version 2.0
		
		if (!(Test-RbaSupportedEnv))
		{
			throw ($UnsupportedEnvMessage)
		}	

		$ErrorActionPreference = [System.Management.Automation.ActionPreference]::Stop
	}
	
	process
	{
		try
		{
			# Deciding how to get a DC object
			if ($PSCmdlet.ParameterSetName -eq "UsingDomainName")
			{
				$dc = (Get-RbaADDomainController -Scope Domain -ScopeValue $Domain)[0]
			}
			else
			{
				$dc = (Get-RbaADDomainController -Scope Computer -ScopeValue $DomainController)[0]
			}

			[int]$allowUpdateValue = 0

			switch ($DynamicUpdate.ToLower())
			{
				"none"					{$allowUpdateValue = 0}
				"nonsecureandsecure"	{$allowUpdateValue = 1}
				"secureonly"			{$allowUpdateValue = 2}
			}

			"Using DynamicUpdate value of $allowUpdateValue" | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput

			# Creating empty return object
			$dnsZone = New-RbaObject -Property @{	"DomainControllerName"=[string]::empty;
													"DNSZoneName"=[string]::empty;
													"DynamicUpdateSettingName"=[string]::empty;
													"DynamicUpdateSettingValue"=0;
													"DistinguishedName"=[string]::empty}
			
			# Getting dns zone distinguished name
			$dnsZoneInfo = (Get-RbaDnsDynamicUpdate -DomainController $dc.dnsHostName -DNSZoneName $DNSZoneName)[0]
			if ($dnsZone -eq $null)
			{
				throw "Could not obtain distinguished name for DNS zone $DNSZoneName."
			}

			if ($PSCmdlet.ShouldProcess($DNSZoneName))
			{
				"Changing zone $DNSZoneName for $DynamicUpdate dynamic updates type."  | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput

				$zone = Get-WmiObject -Namespace root\MicrosoftDNS -Class MicrosoftDNS_Zone -Filter "Name = '$($DNSzoneName)'" -ComputerName $dc.dnsHostName
				$zone.AllowUpdate = $allowUpdateValue
				$zone.Put() | Out-Null

				$dnsZone.DomainControllerName=$dc.Name
				$dnsZone.DNSZoneName=$DNSZoneName
				$dnsZone.DynamicUpdateSettingName=$DynamicUpdate
				$dnsZone.DynamicUpdateSettingValue=$allowUpdateValue
				$dnsZone.DistinguishedName = $dnsZoneInfo.DistinguishedName
			}
		}
		catch
		{
			"An error ocurred trying to configure dns zone dynamic update type." | Log-ErrorToFile -Error $_
			Write-Error "An error ocurred trying to configure dns zone dynamic update type. Error details: $_"	
		}
	}

	end
	{
		"Returned zone name $dnsZone" | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
		"End of Script" | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
		return $dnsZone
	}
}

#------------------------------------------------
# Dot sourcing internal functions used by cmdlets
#------------------------------------------------
. (Join-Path ([System.IO.Path]::GetDirectoryName($MyInvocation.MyCommand.Definition)) "Microsoft.Rba.LogFunctions.ps1")
. (Join-Path ([System.IO.Path]::GetDirectoryName($MyInvocation.MyCommand.Definition)) "Microsoft.Rba.CoreHelper.ps1")
