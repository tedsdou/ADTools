﻿function Remove-RbaComputerDontRequirePreAuth
{
	<#
	.SYNOPSIS
   		Remove-RbaComputerDontRequirePreAuth is a function that removes the Don't Require Kerberos Pre-Authentication option from an object.
	.DESCRIPTION
		Remove-RbaComputerDontRequirePreAuth is a function that removes the Don't Require Kerberos Pre-Authentication option from an object.
	.PARAMETER DistinguishedName
		Distinguished name of an object to remove the DONT_REQUIRE_PREAUTH flag from userAccountControl object property.
	.PARAMETER Computer
		An computer object to remove the DONT_REQUIRE_PREAUTH flag from userAccountControl object property.
	.EXAMPLE
		Remove-RbaComputerDontRequirePreAuth -DistinguishedName "CN=TESTComputer,CN=Computers,DC=contoso,DC=com"
	.EXAMPLE
		Remove-RbaComputerDontRequirePreAuth -Computer (Get-RbaComputerKerberosPreAuthDisabled)
	.EXAMPLE
		Get-RbaComputerKerberosPreAuthDisabled | Remove-RbaComputerDontRequirePreAuth 
	#>

	[CmdletBinding(SupportsShouldProcess=$true,ConfirmImpact="High")]
	param
	(                                
 		[Parameter(Mandatory=$true, ValueFromPipeline=$false, ParameterSetName="DistinguishedName")]
		[array]$DistinguishedName,

 		[Parameter(Mandatory=$true, ValueFromPipeline=$true, ParameterSetName="ADComputer")]
		[array]$Computer
	)
	
    begin
    {
		# Setting up environment
		$ErrorActionPreference = [System.Management.Automation.ActionPreference]::Stop

		Set-StrictMode -Version 2.0
		
		if (!(Test-RbaSupportedEnv))
		{
			$UnsupportedEnvMessage | Add-RbaLogEntry -Severity ([Severity]::Error) -NoConsoleOutput
			throw ($UnsupportedEnvMessage)
		}	
    }
    process
    {
	    try
	    {
			"Removing `"Don`'t Require Pre Authentication`" user account control option" | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput 

			# Checking which parameterset was used, each will have a different set of objects to deal with
			if ($PSCmdlet.ParameterSetName -eq "DistinguishedName")
			{
				foreach ($dn in $DistinguishedName)
				{
					if ($PSCmdlet.ShouldProcess($dn))
					{	
						"Removing Don`'t require pre authentication from $dn" | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput 
						Remove-RbaSingleDontRequirePreAuth -DistinguishedName $dn
					}
				}
			}
			else
			{
				foreach ($dn in $Computer)
				{
					if ($PSCmdlet.ShouldProcess($dn.DistinguishedName))
					{	
						"Removing Don`'t require pre authentication from $($dn.DistinguishedName)" | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput 
						Remove-RbaSingleDontRequirePreAuth -DistinguishedName $dn.DistinguishedName
					}
				}
			}
	    }
	    catch
	    {
		    "An error occurred." | Log-ErrorToFile -Error $_
	    }
    }
	end
	{
		"End of Script" | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput 
	}
}

#------------------------------------------------
# Dot sourcing internal functions used by cmdlets
#------------------------------------------------
. (Join-Path ([System.IO.Path]::GetDirectoryName($MyInvocation.MyCommand.Definition)) "Microsoft.Rba.LogFunctions.ps1")
. (Join-Path ([System.IO.Path]::GetDirectoryName($MyInvocation.MyCommand.Definition)) "Microsoft.Rba.CoreHelper.ps1")
