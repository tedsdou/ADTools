﻿function Get-RbaDownLevelComputerCompoundIdSet
{
	<#
	.SYNOPSIS
   		Get-RbaDownLevelComputerCompoundIdSet is a Powershell function that gets down level computer accounts and checks if its msds-SupportedEncryptionTypes is set to 131072 (Compound-id).
	.DESCRIPTION
   		Get-RbaDownLevelComputerCompoundIdSet is a Powershell function that gets down level computer accounts and checks if its msds-SupportedEncryptionTypes is set to 131072 (Compound-id).
	.PARAMETER Forest
		Performs the operation current forest wide.
	.PARAMETER Domain
		Performs the operation on the specified domain.
	.EXAMPLE
		Look up for down level computer accounts on Contoso.com domain.

		Get-RbaDownLevelComputerCompoundIdSet -Domain Contoso.com
	.EXAMPLE
		Look up for down level computer accounts on the current forest.

		Get-RbaDownLevelComputerCompoundIdSet -Forest
	.NOTES
		Must be executed on each domain with a domain admin account.
	#>
	[CmdletBinding()]
	param
	(
		[Parameter(ParameterSetName="Domain", Mandatory=$true, ValueFromPipeline=$false)]
		[string]$Domain,

		[Parameter(ParameterSetName="Forest", Mandatory=$false)]
        [switch]$Forest
	)

	begin
	{
		# Setting up environment
		$ErrorActionPreference = [System.Management.Automation.ActionPreference]::Stop

		Set-StrictMode -Version 2.0
		
		if (!(Test-RbaSupportedEnv))
		{
			$UnsupportedEnvMessage | Add-RbaLogEntry -Severity ([Severity]::Error) -NoConsoleOutput
			throw ($UnsupportedEnvMessage)
		}	

		Set-Variable MNS_LOGON_ACCOUNT -option Constant -value 131072
	}

	process
	{
		try
		{
			# Obtaining computer list
			"Querying Active Directory for down level clients (Windows 2008 R2 or lower) for compound ID configuration" | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
			
			$allComputers = @()
			$computers = @()

			if ($PSCmdlet.ParameterSetName -eq "Forest")
			{
				"Using Forest search..." | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
				$allComputers  += Get-RbaADObject -Forest -Property distinguishedName,msds-SupportedEncryptionTypes, operatingSystem, operatingSystemVersion -LDAPFilter "(&(objectCategory=computer)(msds-SupportedEncryptionTypes:1.2.840.113556.1.4.803:=$MNS_LOGON_ACCOUNT))" 
			}
			else
			{
				"Using Domain search..." | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
				$computers  += Get-RbaADObject -Scope Domain -ScopeValue $Domain -Property distinguishedName,msds-SupportedEncryptionTypes, operatingSystem, operatingSystemVersion -LDAPFilter "(&(objectCategory=computer)(msds-SupportedEncryptionTypes:1.2.840.113556.1.4.803:=$MNS_LOGON_ACCOUNT))" 
			}

			if ($allComputers.Count -gt 0)
			{
				foreach ($comp in $allComputers)
				{
					if (($comp -ne $null) -and ($comp | gm | select -exp name) -contains 'operatingSystemVersion')
					{
						if (($comp.operatingSystemVersion).Split(' ', [StringSplitOptions]::RemoveEmptyEntries)[0] -le [System.Version]"6.1")
						{
							$computers += $comp
						}
					}
				}
			}
		}
		catch
		{
			"An error occurred querying AD objects." | Log-ErrorToFile -Error $_
		}
	}

	end 
	{
		"Returning $($computers.count) objects" | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
		"End of script" | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
		# Returning affected objects
		return ,$computers
	}
}

#------------------------------------------------
# Dot sourcing internal functions used by cmdlets
#------------------------------------------------
. (Join-Path ([System.IO.Path]::GetDirectoryName($MyInvocation.MyCommand.Definition)) "Microsoft.Rba.LogFunctions.ps1")
. (Join-Path ([System.IO.Path]::GetDirectoryName($MyInvocation.MyCommand.Definition)) "Microsoft.Rba.CoreHelper.ps1")
