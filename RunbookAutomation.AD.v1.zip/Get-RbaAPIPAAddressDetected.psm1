﻿function CheckNetAdapter($DC)
{
    # finds network interfaces with APIPA address

    "Checking network interface configuration on $DC" | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
    try
    {
		$adpaterList = @()
        $interfaces = @(Get-WmiObject Win32_NetworkAdapterConfiguration -Filter "IPEnabled = $true" -ComputerName $DC -ErrorAction SilentlyContinue)

		if ($interfaces -ne $null)
		{
			foreach ($interface in $interfaces)
			{
				$index = $interface.InterfaceIndex
				foreach ($address in ($interface.IPAddress | where {$_ -like "169.254.*"}))
				{
					$adapter = New-RbaObject -Property @{	"Server" = $DC;
															"InterfaceIndex" = $index;
															"IP" = $address
														}
					$adpaterList += $adapter
				}
			}
		}
    }
    catch
    {
		"Error connecting WMI service on $DC" | Log-ErrorToFile -Error $_
        Write-Error "Error connecting WMI service on $DC`n$($_.Exception.Message)" -ErrorAction Continue
    }

	return $adpaterList
 }

function Get-RbaAPIPAAddressDetected
{
	<#
	.SYNOPSIS
   		Get-RbaAPIPAAddressDetected is a Powershell function that returns a list of network interfaces with APIPA address assigned.
	.DESCRIPTION
   		Get-RbaAPIPAAddressDetected is a Powershell function that returns a list of network interfaces with APIPA address assigned.
		This function performs forest wide search, checks a one the domains or specified server.
	.PARAMETER Forest
		Forest FQDN.
	.PARAMETER Domain
		Domain FQDN.
    .PARAMETER Server
        Server FQDN.
	.EXAMPLE
        Get-RbaAPIPAAddressDetected

        Performs forest wide search for a domain controllers with network interfaces with APIPA address assigned.
	.EXAMPLE
		Get-RbaAPIPAAddressDetected -Domain contoso.com

        Performs domain wide search for a domain controllers with network interfaces with APIPA address assigned.
    .EXAMPLE
        Get-RbaAPIPAAddressDetected -Server dc1.contoso.com

        Looks for network interfaces with APIPA address asigned on dc1.contoso.com server.
	.NOTES
		Must be executed with an enterprise admin account.
    .OUTPUTS
        PSObject
	#>

	[CmdletBinding(SupportsShouldProcess=$true, ConfirmImpact="High")]
	param
	(
		[Parameter(ParameterSetName="Domain", Mandatory=$true, ValueFromPipeline=$false)]
		[string]$Domain,

		[Parameter(ParameterSetName="Forest", Mandatory=$false)]
        [switch]$Forest,

        [Parameter(ParameterSetName="Server", Mandatory=$true)]
        [string]$Server
	)

	# Setting up environment
	Set-StrictMode -Version 2.0
		
	if (!(Test-RbaSupportedEnv))
	{
		$UnsupportedEnvMessage | Add-RbaLogEntry -Severity ([Severity]::Error) -NoConsoleOutput
		throw ($UnsupportedEnvMessage)
	}	
		
	$ErrorActionPreference = "Stop"

    # Affected computer list
    $outputList = @()

    $ADforest = [system.directoryservices.activedirectory.Forest]::GetCurrentForest()
    $dcNameList = @()
	$dcList = @()

    switch ($PSCmdlet.ParameterSetName)
    {
        "Server"
            {
                $dcNameList += $Server
                break
            }
        "Domain"
            {
				"Retrieving DCs for $Domain" | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
				try
                {
					$dcList = Get-RbaADDomainController -Scope ([QueryScope]::Domain) -ScopeValue $Domain 
				}
                catch
                {
					"Error retrieving DCs for $Domain." | Log-ErrorToFile -Error $_
                    Write-Error "Error retrieving DCs for $Domain`n$($_.Exception.Message)" -ErrorAction Continue
                }

				if ($dcList -eq $null)
                {
					"Error retrieving DCs for $Domain" | Add-RbaLogEntry -Severity ([Severity]::Error) -NoConsoleOutput
                    Write-Error "Error retrieving DCs for $Domain"
                } 

                foreach ($dc in $dcList)
                {
	                $dcNameList += $dc.Name
                }
                break
            }
        "Forest"
            {
				try
                {
					$dcList  += Get-RbaADDomainController -Forest 
				}
				catch
                {
					"Error retrieving DCs on forest $($ADforest.Name)" | Log-ErrorToFile -Error $_
                    Write-Error "Error retrieving DCs on forest $($ADforest.Name)`n$($_.Exception.Message)" -ErrorAction Continue
                }

                foreach ($dc in $dcList)
                {
	                $dcNameList += $dc.Name
                }
                break
            }
    }

    foreach ($dc in $dcNameList)
	{
		"Checking network interface configuration on $dc" | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
        Write-Progress -Activity "Working..." -Status "Checking network interface configuration on $dc"
		foreach ($item in (CheckNetAdapter $dc))
		{
			if ($item -ne $null)
			{
				$outputList += $item
			}
		}
    }
    
	if ($outputList -ne $null)
	{
		return ,$outputList
	}
	else
	{
		return $null
	}
}

#------------------------------------------------
# Dot sourcing internal functions used by cmdlets
#------------------------------------------------
. (Join-Path ([System.IO.Path]::GetDirectoryName($MyInvocation.MyCommand.Definition)) "Microsoft.Rba.LogFunctions.ps1")
. (Join-Path ([System.IO.Path]::GetDirectoryName($MyInvocation.MyCommand.Definition)) "Microsoft.Rba.CoreHelper.ps1")
