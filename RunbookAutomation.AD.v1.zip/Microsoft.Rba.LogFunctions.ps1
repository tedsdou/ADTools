<#
.SYNOPSIS
   Microsoft.Rba.LogFunctions.ps1 - This module contains generic functions for logging, this should be DOT sourced on every script that needs logging
.DESCRIPTION
   Microsoft.Rba.LogFunctions.ps1 - This module contains generic functions for logging, this should be DOT sourced on every script that needs logging
#>
#------------------------------------------------
# Variables, Enumerators and Classes Definition
#------------------------------------------------
$enumSeverityDef = @"
public enum Severity
{	
	Info,
	Warn,
	Error
}
"@
try { Add-Type -TypeDefinition $enumSeveritydef } catch {}

function Add-RbaLogEntry
{
	<#
	.SYNOPSIS
	   	Adds a log entry in a defined log file.
	.DESCRIPTION
	   	Adds a log entry in a defined log file.
	.PARAMETER Severity
		Severity string, which can be obtained from severity enum (Informational, Warning, Error)
	.PARAMETER NoConsoleOutput
		Does not shows message that was logged on file to screen
	.PARAMETER Clobber
		Rewrites log file
	.EXAMPLE
		"Importing ServerManager Module..." | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
	.EXAMPLE
		Add-LogEntry  -ModuleName "MyfileName" -FunctionName "MyFunction"  -LogFileName "c:\temp\mylog.log" -Severity "Warning" -Message "This is a sample message"
	#>
    [CmdletBinding()]
	param
	(
		[Parameter(Mandatory=$true)]
		[ValidateNotNullOrEmpty()]
		[string] $Severity,
		
		[Parameter(Mandatory=$true,ValueFromPipeline=$true)]
		[ValidateNotNullOrEmpty()]
		[string] $Message,
		
		[Parameter(Mandatory=$false)]
		[switch] $Clobber=$false,

		[Parameter(Mandatory=$false)]
		[switch] $NoConsoleOutput=$false,
        
        [Parameter(Mandatory=$false)]
        [int]$CallStackItem=1
   	)

    $callStack = Get-PSCallStack
   
    $moduleName = $callStack[$callStackItem].Location.Split(":")[0]
    
    $callStack[$callStackItem].Location.Split(":")[1].Trim() -imatch '(\d+)' | Out-null
    $lineNumber = $matches[0]
    
    $logFileName = [string]::Format("{0}.log",$callStack[$callStackItem].ScriptName)
    $functionName = $callStack[$callStackItem].Command
    
	if ($Clobber)
	{
		[System.IO.FileStream] $fs = New-Object System.IO.FileStream($LogFileName,[System.IO.FileMode]::Create)
	}
	else
	{
		[System.IO.FileStream] $fs = New-Object System.IO.FileStream($LogFileName,[System.IO.FileMode]::Append)
	}

	[System.IO.StreamWriter] $sw = New-Object System.IO.StreamWriter($fs,[System.Text.Encoding]::UTF8)
	
	[string]$FormatedLine = [string]::Format("{0}|{1}|{2}|{3}|{4}|{5}",[datetime]::Now,$ModuleName,$FunctionName,$lineNumber,$Severity,$Message)
	$sw.WriteLine($FormatedLine)
	$sw.Dispose()
	$fs.Dispose()

	if ($callStack[$callStackItem].Arguments.ToLower().Contains("verbose=true"))
	{
		Write-Verbose $FormatedLine
	}
	
	if (!($NoConsoleOutput))
	{
		Write-RbaScreenMessage -Severity $Severity -Message $FormatedLine
	}
}

function Log-ErrorToFile
{
    [CmdletBinding()]
	param
	(
		[Parameter(Mandatory=$true,ValueFromPipeline=$true)]
		[string]$Message,

		[Parameter(Mandatory=$true)]
		$Error
	)

	"An Error Ocurred." | Add-RbaLogEntry -Severity ([Severity]::Error) -NoConsoleOutput -CallStackItem 2
	"Error Details" | Add-RbaLogEntry -Severity ([Severity]::Error) -NoConsoleOutput -CallStackItem 2
	"--------------------------------------------------------------" | Add-RbaLogEntry -Severity ([Severity]::Error) -NoConsoleOutput -CallStackItem 2
    "   Exception: $($Error.Exception)" | Add-RbaLogEntry -Severity ([Severity]::Error) -NoConsoleOutput -CallStackItem 2
    "   Command: $($Error.InvocationInfo.MyCommand)" | Add-RbaLogEntry -Severity ([Severity]::Error) -NoConsoleOutput -CallStackItem 2
    "   ScriptName: $($Error.InvocationInfo.ScriptName)" | Add-RbaLogEntry -Severity ([Severity]::Error) -NoConsoleOutput -CallStackItem 2
    "   Line: $($Error.InvocationInfo.Line)" | Add-RbaLogEntry -Severity ([Severity]::Error) -NoConsoleOutput -CallStackItem 2
    "   ScriptLineNumber: $($Error.InvocationInfo.ScriptLineNumber)" | Add-RbaLogEntry -Severity ([Severity]::Error) -NoConsoleOutput -CallStackItem 2
    "   Position: $($Error.InvocationInfo.OffsetInLine)" | Add-RbaLogEntry -Severity ([Severity]::Error) -NoConsoleOutput -CallStackItem 2
}

function Write-RbaScreenMessage
{
	<#
	.SYNOPSIS
	   	Outputs messages to host console
	.DESCRIPTION
	   	Outputs messages to host console
	.PARAMETER Message
		Message to output
	.PARAMETER Severity
		Severity string, which can be obtained from severity enum (Info, Warn, Error)
	#>
    [CmdletBinding()]
	param
	(
		[Parameter(Mandatory=$true)]
		[ValidateNotNullOrEmpty()]
		[string] $Severity,
        
		[Parameter(Mandatory=$true)]
		[ValidateNotNullOrEmpty()]
		[string] $Message
   	)
	
	switch ($Severity)
	{
		"Info"
			{
				Write-Host $Message -ForegroundColor Cyan
			}
		"Warn"
			{
				Write-Host $Message -ForegroundColor Yellow
			}
		"Error"
			{
				Write-Host $Message -ForegroundColor White -BackgroundColor Red
			}
	}
	
}