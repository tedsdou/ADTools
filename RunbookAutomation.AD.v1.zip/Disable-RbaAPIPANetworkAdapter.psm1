﻿function Disable-RbaAPIPANetworkAdapter
{
	<#
	.SYNOPSIS
   		Disable-RbaAPIPANetworkAdapter is a Powershell function that disables network adapter with APIPA IP address.
	.DESCRIPTION
   		Disable-RbaAPIPANetworkAdapter is a Powershell function that disables network adapter with APIPA IP address.
	.PARAMETER Server
		Server FQDN.
    .PARAMETER InterfaceIndex
        Index of network adapter that was returned by Get-RbaAPIPAAddressDetected cmdlet.
	.EXAMPLE
        Disable-RbaAPIPANetworkAdapter -Server dc1.contoso.com -InterfaceIndex 16

        Disables network interface no. 16 on dc1.contoso.com.
	.EXAMPLE
		Get-RbaAPIPAAddressDetected -Server dc1.contoso.com | Disable-RbaAPIPANetworkAdapter

        Disables network interface with APIPA address assigned (if found) on dc1.contoso.com.
	.NOTES
		Must be executed with an enterprise admin account.
	#>

    [CmdletBinding(SupportsShouldProcess=$true, ConfirmImpact="High")]
    param
    (
        [Parameter(Mandatory=$true, ValueFromPipeline=$false, ValueFromPipelineByPropertyName=$true)]
		[string]$Server,

        [Parameter(Mandatory=$true, ValueFromPipeline=$false, ValueFromPipelineByPropertyName=$true)]
		[string]$InterfaceIndex
    )

    begin
    {
    	# Setting up environment
	    Set-StrictMode -Version 2.0
		
    	if (!(Test-RbaSupportedEnv))
	    {
		    $UnsupportedEnvMessage | Add-RbaLogEntry -Severity ([Severity]::Error) -NoConsoleOutput
			throw ($UnsupportedEnvMessage)
    	}	
		
	    $ErrorActionPreference = "Stop"
    }

    process
    {
        try
        {
			"Calling WMI against interface $InterfaceIndex on $Server" | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
            $interface = Get-WmiObject Win32_NetworkAdapter -Filter "InterfaceIndex=$InterfaceIndex" -ComputerName $Server

            $yes = New-Object System.Management.Automation.Host.ChoiceDescription("&Yes","")
            $no = New-Object System.Management.Automation.Host.ChoiceDescription("&No","")
            $choices = [System.Management.Automation.Host.ChoiceDescription[]]($yes, $no)
            $chosen = $host.ui.PromptForChoice("Confirm","Are you sure you want to perform this action?`nPerforming operation `"Disabling interface no. $InterfaceIndex`" on target `"$Server`"", $choices, 0)

            if ($chosen -eq 0)
            {
				"Disabling interface $InterfaceIndex on $Server" | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
                $result = $interface.Disable()
                if ($result.ReturnValue -ne 0)
                {
					"Disable interface failed with code $($result.ReturnValue)" | Add-RbaLogEntry -Severity ([Severity]::Error) -NoConsoleOutput
                    throw "Disable interface failed with code $($result.ReturnValue)"
                }
				else
				{
					"Interface no. $InterfaceIndex on $Server was disabled" | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
				}
            }
        }
        catch
        {
			"Error processing WMI request on $Server" | Log-ErrorToFile -Error $_
			Write-Error "Error processing WMI request on $Server`n$($_.Exception.Message)" -ErrorAction Continue
        }
    }
}

#------------------------------------------------
# Dot sourcing internal functions used by cmdlets
#------------------------------------------------
. (Join-Path ([System.IO.Path]::GetDirectoryName($MyInvocation.MyCommand.Definition)) "Microsoft.Rba.LogFunctions.ps1")
. (Join-Path ([System.IO.Path]::GetDirectoryName($MyInvocation.MyCommand.Definition)) "Microsoft.Rba.CoreHelper.ps1")
