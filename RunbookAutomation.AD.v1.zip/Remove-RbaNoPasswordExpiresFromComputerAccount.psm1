﻿function Remove-RbaNoPasswordExpiresFromComputerAccount
{
	<#
	.SYNOPSIS
   		Remove-RbaNoPasswordExpiresFromComputerAccounts is a Powershell function that queries AD for computers that are set don't expire password and remove this bit from userAccountControl.
	.DESCRIPTION
   		Remove-RbaNoPasswordExpiresFromComputerAccounts is a Powershell function that queries AD for computers that are set don't expire password and remove this bit from userAccountControl.
	.PARAMETER ComputerDN
		Optional parameter for computer distinguished names, if this parameter is null or empty then change will happen against all computer accounts
	.EXAMPLE
		Remove password does not expire flag from all computer objects in the current domain.

		Remove-RbaNoPasswordExpiresFromComputerAccount
	.EXAMPLE
		Remove password does not expire flag from computer object "Workstation01".

		Remove-RbaNoPasswordExpiresFromComputerAccount -ComputerDN "CN=Workstation01,CN=Computer,DC=contoso,DC=com"

	.RETURNS
		A list of affected computer objects.
	.NOTES
		Must be executed on each domain with a domain admin account.
	#>
	[CmdletBinding(SupportsShouldProcess=$true,ConfirmImpact="High")]
	param
	(
		[Parameter(Mandatory=$false, ValueFromPipeline=$true)]
		[string]$ComputerDN
	)

    begin
    {
		# Setting up environment
		$ErrorActionPreference = [System.Management.Automation.ActionPreference]::Stop

		Set-StrictMode -Version 2.0
		
		if (!(Test-RbaSupportedEnv))
		{
			$UnsupportedEnvMessage | Add-RbaLogEntry -Severity ([Severity]::Error) -NoConsoleOutput
			throw ($UnsupportedEnvMessage)
		}	

		# Constants
		Set-Variable DONT_EXPIRE_PASSWD -option Constant -value 65536

        # Affected computer list
        $outputList = @()
    }

	process
	{
		# Initialize computerlist for this unique processing from pipeline
        $computerList = @()
		
		# Modify query depending if computer name was passed or not
        if ([string]::IsNullOrEmpty($ComputerDN))
		{
			"Getting list of computer accounts in domain that are configured for password don`'t expires" | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
			$computerList  += Get-RbaADObject -Forest -LDAPFilter "(&(objectCategory=computer)(userAccountControl:1.2.840.113556.1.4.803:=$DONT_EXPIRE_PASSWD))" -Property UserAccountControl, DistinguishedName
		}
		else
		{
			"Getting computer account $ComputerDN" | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
			$computerList += Get-RbaADObject -Forest -LDAPFilter "(&(objectCategory=computer)(distinguishedName=$ComputerDN)(userAccountControl:1.2.840.113556.1.4.803:=$DONT_EXPIRE_PASSWD))" -Property UserAccountControl, DistinguishedName
		}
        
		# Perform changes
		if ($computerList.Count -gt 0)
		{
			foreach ($computer in $computerList)
			{
				if ($computer -ne $null)
				{
					if ($PSCmdlet.ShouldProcess($computer.distinguishedname))
					{
						$newUserAccountControl = $computer.userAccountControl -bxor $DONT_EXPIRE_PASSWD

						$domainName = $computer.DistinguishedName.ToUpper().Substring($computer.DistinguishedName.ToUpper().IndexOf("DC=")+3, $computer.DistinguishedName.Length - ($computer.DistinguishedName.ToUpper().IndexOf("DC=")+3)).Replace(",DC=",".") 
						$dcObj = (Get-RbaADDomainController -Scope Domain -ScopeValue $domainName)[0]

						Set-RbaADObject -Identity $computer.DistinguishedName -Replace @{userAccountControl=$newUserAccountControl} -DomainController $dcObj.Name
                    
						if (-not (Exists -List $outputList -Item $computer))
						{
							$outputList += $computer
						}
					}
				}
			}
		}
	}

	end
	{
		"Returned objects count $($outputList.Count)" | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
		"End of Script" | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput 
		# Return a list of affected objects
		return ,$outputList
	}
}

#------------------------------------------------
# Dot sourcing internal functions used by cmdlets
#------------------------------------------------
. (Join-Path ([System.IO.Path]::GetDirectoryName($MyInvocation.MyCommand.Definition)) "Microsoft.Rba.LogFunctions.ps1")
. (Join-Path ([System.IO.Path]::GetDirectoryName($MyInvocation.MyCommand.Definition)) "Microsoft.Rba.CoreHelper.ps1")
