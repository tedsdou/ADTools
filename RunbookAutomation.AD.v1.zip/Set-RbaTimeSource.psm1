function Set-RbaTimeSource
{
	<#
	.SYNOPSIS
   		Set-RbaTimeSource is a Powershell function that set ntp time source to the target computer.
	.DESCRIPTION
   		Set-RbaTimeSource is a Powershell function that set ntp time source to the target computer.
	.PARAMETER NTPServer
		NTPServer, has to be valid ntp server name or ip address. It can be multiple ntp servers.
    .PARAMETER DomainController
		DomainController to set the time source parameter, has to be FQDN or Computer Name.
        When you execute the function locally, you can ignore this parameter.
	.EXAMPLE
		Set ntp time source to local computer.

		Set-RbaTimeSource -NTPServer server01.example.com
	.EXAMPLE
		Set multiple ntp time source to remote computer DC05.contoso.com.

		Set-RbaTimeSource -NTPServer server01.example.com, server02.example.com -TargetComputer DC05.contoso.com
	.NOTES
        It requires PS version 2.0, 3.0, or 4.0.
		
	#>
    [CmdletBinding(SupportsShouldProcess=$true, ConfirmImpact="High")]
	param
	(                                
 		[Parameter(Mandatory=$true)]
		[array]$NTPServer,
 		[Parameter(Mandatory=$false, ValueFromPipeline = $true)]
		[string]$DomainController
	)

    #---------------------------------------
	# Preparing process
	#---------------------------------------
    begin
	{
		# Setting up environment
		Set-StrictMode -Version 2.0
		
		if (!(Test-RbaSupportedEnv))
		{
			throw ($UnsupportedEnvMessage)
		}	
		
		$ErrorActionPreference = [System.Management.Automation.ActionPreference]::Stop
	}

    #---------------------------------------
	# Main function process
	#---------------------------------------
    process
    {
	    try
	    {
			if ([string]::IsNullOrEmpty($DomainController))
			{
				$computerName = $ENV:COMPUTERNAME
			}
			else
			{
				$computerName = $DomainController
			}

            $serverList = ""

            # process the time sources as input parameter of w32tm
            if ($NTPServer.Count -gt 1) # for multiple time sources
            {
                foreach ($ntp in $NTPServer)  
                {
					if (!$ntp.contains(",0x"))
					{
						$serverList += "$ntp,0x9 "
					}
                    else
					{
						$serverList += "$ntp "
					}
                }

                # delete the last space
                $ServerList = $ServerList.Trim()
            }
            else # for single time source
            {
				if (!$NTPServer[0].contains(",0x"))
				{
					$serverList = "$($NTPServer[0]),0x9"
				}
				else
				{
					$serverList = $NTPServer[0]
				}
            }


            if ($PSCmdlet.ShouldProcess($computerName,"Change Time Source"))
	        {
                # Set the time source servers to the target computer
				"Changing time source to $serverList ..." | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
                w32tm /config /computer:$computerName /manualpeerlist:"$serverList" /syncfromflags:manual /reliable:yes /update
            }
            
	    }
	    catch
	    {
			"An error ocurred trying to set time source of target computer." | Log-ErrorToFile -Error $_
		    Write-Error "An error ocurred trying to set time source of target computer. Error details: $_"	
	    }
    }
	
	end
	{
		"End of Script" | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
	}

}

#------------------------------------------------
# Dot sourcing internal functions used by cmdlets
#------------------------------------------------
. (Join-Path ([System.IO.Path]::GetDirectoryName($MyInvocation.MyCommand.Definition)) "Microsoft.Rba.LogFunctions.ps1")
. (Join-Path ([System.IO.Path]::GetDirectoryName($MyInvocation.MyCommand.Definition)) "Microsoft.Rba.CoreHelper.ps1")
