﻿function Set-RbaDownLevelComputerSupportedEncryptionDefaults
{
	<#
	.SYNOPSIS
   		Set-RbaDownLevelComputerSupportedEncryptionDefaults is a Powershell script removes Compound-id bit (131072) from all down level computers (Windows 2008 R2 or below) from current domain.
		If true it sets this value back to 31.
	.DESCRIPTION
   		Set-RbaDownLevelComputerSupportedEncryptionDefaults is a Powershell script removes Compound-id bit (131072) from all down level computers (Windows 2008 R2 or below) from current domain..
		If true it sets this value back to 31.
	.EXAMPLE
		Look up for down level computer accounts on the current domain, set to default value.

		Get-RbaDownLevelComputerCompoundIdSet
	.NOTES
		Must be executed on each domain with a domain admin account.
	#>
	[CmdletBinding(SupportsShouldProcess=$true,ConfirmImpact="High")]
	param
	()

	begin
	{
		# Setting up environment
		$ErrorActionPreference = [System.Management.Automation.ActionPreference]::Stop

		Set-StrictMode -Version 2.0
		
		if (!(Test-RbaSupportedEnv))
		{
			$UnsupportedEnvMessage | Add-RbaLogEntry -Severity ([Severity]::Error) -NoConsoleOutput
			throw ($UnsupportedEnvMessage)
		}	

		Set-Variable MNS_LOGON_ACCOUNT -option Constant -value 131072
	}

	process
	{
		try
		{
			$currDomain = [system.directoryservices.activedirectory.domain]::GetCurrentDomain()
			$dcObj = (Get-RbaADDomainController -Scope ([QueryScope]::Domain) -ScopeValue $currDomain)[0]

			# Obtaining target list
			"Querying Active Directory for down level clients (Windows 2008 R2 or lower) for compound ID configuration" | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
			$computers = Get-RbaDownLevelComputerCompoundIdSet -Domain $currDomain.Name
		
			# Performing changes if ShouldProcess = true
			"Removing compound ID configuration from down level clients" | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
			if ($computers -ne $null)
			{
				foreach ($computer in $computers)
				{
					if ($PSCmdlet.ShouldProcess($computer.DistinguishedName))
					{
						$msDSSupportedEncryptionTypes = $computer."msDS-SupportedEncryptionTypes"
						$msDSSupportedEncryptionTypes = $msDSSupportedEncryptionTypes -bxor $MNS_LOGON_ACCOUNT
						Set-RbaADObject -Identity $computer.DistinguishedName -Replace @{"msDS-SupportedEncryptionTypes"=$msDSSupportedEncryptionTypes} -DomainController $dcObj.Name
					}
				}
			}
		}
		catch
		{
			"An error occurred." | Log-ErrorToFile -Error $_
		}
	}

	end 
	{
		"Returned objects count $($computers.Count)" | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
		"End of Script" | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput 
		# Returning affected objects
		return $computers
	}
}

#------------------------------------------------
# Dot sourcing internal functions used by cmdlets
#------------------------------------------------
. (Join-Path ([System.IO.Path]::GetDirectoryName($MyInvocation.MyCommand.Definition)) "Microsoft.Rba.LogFunctions.ps1")
. (Join-Path ([System.IO.Path]::GetDirectoryName($MyInvocation.MyCommand.Definition)) "Microsoft.Rba.CoreHelper.ps1")
