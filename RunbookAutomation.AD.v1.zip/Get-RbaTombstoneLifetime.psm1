﻿function Get-RbaTombstoneLifetime
{
	<#
	.SYNOPSIS
   		Get-RbaTombstoneLifetime is a Powershell function that get forest tombstone lifetime.
	.DESCRIPTION
   		Get-RbaTombstoneLifetime is a Powershell function that get forest tombstone lifetime.
	.EXAMPLE
		Get tombstone lifetime of forest.
		Get-RbaTombstoneLifetime
	.NOTES
		It requires Root Domain Administrator priviledge. 
        It requires PS version 2.0, 3.0, or 4.0.
		
	#>
    
    #---------------------------------------
	# Preparing process
	#---------------------------------------
    begin
	{
		# Setting up environment
		Set-StrictMode -Version 2.0
		
		if (!(Test-RbaSupportedEnv))
		{
			$UnsupportedEnvMessage | Add-RbaLogEntry -Severity ([Severity]::Error) -NoConsoleOutput
			throw ($UnsupportedEnvMessage)
		}	
		$ErrorActionPreference = [System.Management.Automation.ActionPreference]::Stop
	}
    #---------------------------------------
	# Main function process
	#---------------------------------------
    Process
    {
	    try
	    {
            
            # Get Forest Configuration Naming Context
			"Getting Forest Configuration Naming Context..." | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
			$configurationNamingContext = (New-Object DirectoryServices.DirectoryEntry("LDAP://RootDSE")).configurationNamingContext

            # Get tombstone lifetime for the forest
            "Get tombstone lifetime for the forest..." | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
			$tombstoneLifetimeValueSet = (GetRbaADObject -Identity "CN=Directory Service,CN=Windows NT,CN=Services,$configurationNamingContext" -Property tombstonelifetime).TombstoneLifetime

            if($tombstoneLifetimeValueSet -eq $null)
            {
                $tombstoneLifetimeValueSet = "<not set>"
                $tombstoneLifetime = 60
            }
            else
            {
                if($tombstoneLifetimeValueSet -gt 2) 
                {
                    $tombstoneLifetime = $tombstoneLifetimeValueSet
                }
                else
                {
					# minimum value is 2
                    $tombstoneLifetime = 2;
                }
            }

            # Creating user object
			# Using New-RbaObject due to the fact that Powershell 2.0 does not support creating PSobjects using a hash table for properties
            $forestTSL = New-RbaObject -Property @{	"TombstoneLifetime" = $tombstoneLifetime;
													"TombstoneLifetimeValueSet" = $tombstoneLifetimeValueSet;
													"Forest"=([system.directoryservices.activedirectory.Forest]::GetCurrentForest()).Name }
	    }
	    catch
	    {
			"An error ocurred trying to get Tombstone Lifetime. Error details: $_" | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
		    Write-Error "An error ocurred trying to get Tombstone Lifetime. Error details: $_"	
	    }
    }

    End
    {
		"End of Script" | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
        # Result
        return $forestTSL
    }
}

#------------------------------------------------
# Dot sourcing internal functions used by cmdlets
#------------------------------------------------
. (Join-Path ([System.IO.Path]::GetDirectoryName($MyInvocation.MyCommand.Definition)) "Microsoft.Rba.LogFunctions.ps1")
. (Join-Path ([System.IO.Path]::GetDirectoryName($MyInvocation.MyCommand.Definition)) "Microsoft.Rba.CoreHelper.ps1")
