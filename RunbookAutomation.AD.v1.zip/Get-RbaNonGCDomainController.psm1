﻿function Get-RbaNonGCDomainController
{
	<#
	.SYNOPSIS
   		Get-RbaNonGCDomainController is a Powershell function that returns a list of domain controllers that are not global catalogs.
	.DESCRIPTION
   		Get-RbaNonGCDomainController is a Powershell function that returns a list of domain controllers that are not global catalogs, this query can be done on domain or forest levels.
   	.PARAMETER Domain
		Domain name to query non global catalog servers in specified domain.
   	.PARAMETER Forest 
		Switch parameter to query non global catalog servers in current forest.
	.EXAMPLE
   		Get-RbdNonGCDomainController -Domain contoso.com

		Gets all non GCs from Contoso.com domain.
	.EXAMPLE
   		Get-RbdNonGCDomainController -Forest

		Gets all non GCs from current forest.
	.RETURNS
   		List of System.DirectoryServices.ActiveDirectory.DomainController domain controllers that are not global catalog servers.
	.NOTES
		Must be executed with a domain admin account or enterprise admin if scope is forest.
	#>
	[CmdletBinding()]
	param
	(
		[Parameter(ParameterSetName="Domain", Mandatory=$true, ValueFromPipeline=$false)]
		[string]$Domain,

		[Parameter(ParameterSetName="Forest", Mandatory=$false)]
        [switch]$Forest
	)

	begin
	{
		# Setting up environment
		$ErrorActionPreference = [System.Management.Automation.ActionPreference]::Stop

		Set-StrictMode -Version 2.0
		
		if (!(Test-RbaSupportedEnv))
		{
			$UnsupportedEnvMessage | Add-RbaLogEntry -Severity ([Severity]::Error) -NoConsoleOutput
			throw ($UnsupportedEnvMessage)
		}	
	}

	process
	{
		try
		{
			# Obtaining computer list
			"Querying Active Directory for non Global Catalog Domain Controllers" | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
		
			$nonGCs = @()
			$dcList = @()

			if ($PSCmdlet.ParameterSetName -eq "Forest")
			{
				"Using Forest search..." | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
				$dcList  += Get-RbaADDomainController -Forest
			}
			else
			{
				"Using Domain search..." | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
				$dcList += Get-RbaADDomainController -Scope ([QueryScope]::Domain) -ScopeValue $Domain 
			}

			"Filtering non Global Catalog Domain Controllers" | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput

			foreach ($dc in $dcList)
			{
                if ((CheckNTDSConfig -option 1 -DomainController $dc.Name) -eq $null)
                {
                    $nonGCs += $dc
                }
			}
		}
		catch
		{
			"An error ocurred." | Log-ErrorToFile -Error $_
		}
	}

	end 
	{
		"Returning $($nonGCs.count) objects" | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
		"End of script" | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
		# Returning affected objects
		return ,$nonGCs
	}
}

#------------------------------------------------
# Dot sourcing internal functions used by cmdlets
#------------------------------------------------
. (Join-Path ([System.IO.Path]::GetDirectoryName($MyInvocation.MyCommand.Definition)) "Microsoft.Rba.LogFunctions.ps1")
. (Join-Path ([System.IO.Path]::GetDirectoryName($MyInvocation.MyCommand.Definition)) "Microsoft.Rba.CoreHelper.ps1")
