﻿function Get-RbaPasswordNeverSet
{
	<#
	.SYNOPSIS
   		Get-RbaPasswordNeverSet is a Powershell function that returns a list of users that never changed its password or passwords that are set to be changed at next logon.
	.DESCRIPTION
   		Get-RbaPasswordNeverSet is a Powershell function that returns a list of users that never changed its password or passwords that are set to be changed at next logon.
		This function gets all users from all domains within the forest.
	.PARAMETER DomainController
		Domain controller FQDN.
	.PARAMETER Domain
		Domain FQDN name.
	.EXAMPLE
		Gets the password never set status from users of a specific domain.

		Get-RbaPasswordNeverSet -Domain "Contoso.com"
	.EXAMPLE
		Gets the password never set status from users of a specific domain controller.

		Get-RbaPasswordNeverSet -DomainController "DC01.Contoso.com"
	.RETURNS
		PSObject list with following attributes:
			UserDN
			UnicodePwdVersion
			pwdLastSet
			pwdLastSetDate
			Status
	.NOTES
		Must be executed on root domain with a domain admin account.
		Change the line below "Result" comment in order to modify returned results filtering.
		Apply Powershell filters to obtaing specific objects based on defined criteria.

		Valid status strings:
			InitialAdminPassword
			PasswordNeverSet
			PasswordHasBeenChanged
			UserMustChangePasswordAtNextLogon
	#>
	[CmdletBinding()]
	param
	(                                
 		[Parameter(Mandatory=$true, ParameterSetName="UsingDCName")]
		[string]$DomainController,

 		[Parameter(Mandatory=$true, ParameterSetName="UsingDomainName")]
		[string]$Domain
	)

	begin
	{
		# Setting up environment
		$ErrorActionPreference = [System.Management.Automation.ActionPreference]::Stop

		Set-StrictMode -Version 2.0
		
		if (!(Test-RbaSupportedEnv))
		{
			$UnsupportedEnvMessage | Add-RbaLogEntry -Severity ([Severity]::Error) -NoConsoleOutput
			throw ($UnsupportedEnvMessage)
		}	

		# Initialize return array
		$userList = @()
	}
	
	process
	{
		try
		{
			# Deciding how to get a DC object
			"Deciding how to get a DC object " | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
			if ($PSCmdlet.ParameterSetName -eq "UsingDomainName")
			{
				$dc = (Get-RbaADDomainController -Scope Domain -ScopeValue $Domain)[0]
				$DomainFQDN = $domain
			}
			else
			{
				$dc = (Get-RbaADDomainController -Scope Computer -ScopeValue $DomainController)[0]
				$DomainFQDN = Get-DNSSuffixFromDCName $dc.dnshostname
			}

			"Using DC $($DC.Name)" | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput

			# Getting metadata for each user object
			"Getting metadata for each user object" | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
			
			$users = GetRbaADObject -LDAPFilter "(objectClass=user)" -Property DistinguishedName,pwdLastSet -DomainController $dc.Name -DomainFQDN $DomainFQDN -SearchScope ([System.DirectoryServices.SearchScope]::Subtree)

			foreach ($userObject in $users)
			{
				$objMetadata = (GetRbaADObject -Identity $userObject.distinguishedname -DomainController $dc.Name -Property "msds-replattributemetadata")."msds-replattributemetadata"
				$metadataList = Convert-MetadataToHashTable -Metadata $objMetadata

				$unicodePwd = $metadataList.unicodepwd.dwVersion

				# Setting up status attribute
				switch ($unicodePwd)
				{
					"1"
						{
							if ($userObject.DistinguishedName.Contains("CN=Administrator,"))
							{
								$status = "InitialAdminPassword"
							}
							else
							{
								$status = "PasswordNeverSet"
							}
						}
					
					"2" 
						{ 
							$status = "InitialPassword"
						}
				
					default
						{ 
							$status = "PasswordHasBeenChanged"
						}
				}
			
				if ($userObject.pwdLastSet -eq "0")
				{
					$status = "UserMustChangePasswordAtNextLogon"
				}
			
				# Creating user object
				# Using New-RbaObject due to the fact that Powershell 2.0 does not support creating PSobjects using a hash table for properties
				$user = New-RbaObject -Property @{	"UserDN"=$userObject.DistinguishedName;
													"UnicodePwdVersion"=$unicodePwd;
													"pwdLastSet"=$userObject.pwdLastSet;
													"pwdLastSetDate"= ([DateTime]::FromFileTimeUtc($userObject.pwdLastSet));
													"Status"=$status }

				# Adding user to the user return list
				$userList += $user
			}
		}
		catch
		{
			"An error ocurred trying to get object metadata." | Log-ErrorToFile -Error $_
			Write-Error "An error ocurred trying to get object metadata. Error details: $_"	
		}
	}

	end
	{
		"Returned objects count $($userList.Count)" | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
		"End of Script" | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput 
		# Results
		return ,$userList
	}
}

#------------------------------------------------
# Dot sourcing internal functions used by cmdlets
#------------------------------------------------
. (Join-Path ([System.IO.Path]::GetDirectoryName($MyInvocation.MyCommand.Definition)) "Microsoft.Rba.LogFunctions.ps1")
. (Join-Path ([System.IO.Path]::GetDirectoryName($MyInvocation.MyCommand.Definition)) "Microsoft.Rba.CoreHelper.ps1")
