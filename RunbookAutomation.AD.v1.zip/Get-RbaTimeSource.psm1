function Get-RbaTimeSource
{
	<#
	.SYNOPSIS
   		Get-RbaTimeSource is a Powershell function that gets ntp time sources configured at a specified DC.
	.DESCRIPTION
   		Get-RbaTimeSource is a Powershell function that gets ntp time sources configured at a specified DC.
    .PARAMETER DomainController
		DomainController to set the time source parameter, has to be FQDN or Computer Name.
        When you execute the function locally, you can ignore this parameter.
	.EXAMPLE
		Gets configured NTP Server.

		Get-RbaTimeSource -DomainController corpdc01
	.EXAMPLE
		Gets configured NTP Servers on local host

		Get-RbaTimeSource
	.NOTES
        It requires PS version 2.0, 3.0, or 4.0.
		
	#>
    [CmdletBinding(SupportsShouldProcess=$true, ConfirmImpact="High")]
	param
	(                                
 		[Parameter(Mandatory=$false, ValueFromPipeline = $true)]
		[string]$DomainController
	)

    #---------------------------------------
	# Preparing process
	#---------------------------------------
    begin
	{
		# Setting up environment
		Set-StrictMode -Version 2.0
		
		if (!(Test-RbaSupportedEnv))
		{
			throw ($UnsupportedEnvMessage)
		}	
		
		$ErrorActionPreference = [System.Management.Automation.ActionPreference]::Stop

		$returnList = @()
	}

    #---------------------------------------
	# Main function process
	#---------------------------------------
    process
    {
	    try
	    {
			if ([string]::IsNullOrEmpty($DomainController))
			{
				$computerName = $ENV:COMPUTERNAME
			}
			else
			{
				$computerName = $DomainController
			}

			"Connecting $computerName remote registry..." | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
            $reg=[Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey('LocalMachine', $computerName)

			"Openning SubKey HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\W32Time\Parameters..." | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
            $key=$reg.OpenSubKey('SYSTEM\CurrentControlSet\Services\W32Time\Parameters', $false)

			try
			{
				"Getting NtpServer value..." | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
				$ntp = $key.GetValue('NtpServer')

				$ntpRawList = $ntp.Split(" ")

				foreach ($ntpItem in $ntpRawList)
				{
					if ($ntpItem.Contains(","))
					{
						$returnList +=  New-RbaObject -Property @{'DomainController'=$computerName;
													'NTPServer'=($ntpItem.Split(","))[0];
													'Flag'=($ntpItem.Split(","))[1]}

					}
					else
					{
						$returnList +=  New-RbaObject -Property @{'DomainController'=$computerName;
																	'NTPServer'=($ntpItem.Split(","))[0];
																	'Flag'=""}
					}
					
				}

			}
			catch
			{
				"An error ocurred trying to get NtpServer registry value." | Log-ErrorToFile -Error $_
			}

							
			"Closing $key..." | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
            $key.Close()

            "Closing $reg..." | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
            $reg.Close()
            
	    }
	    catch
	    {
			"An error ocurred trying to get NTP time source of target computer." | Log-ErrorToFile -Error $_
		    Write-Error "An error ocurred trying to get NTP time source of target computer. Error details: $_"	
	    }
    }
	
	end
	{
		,$returnList
		"End of Script" | Add-RbaLogEntry -Severity ([Severity]::Info) -NoConsoleOutput
	}

}

#------------------------------------------------
# Dot sourcing internal functions used by cmdlets
#------------------------------------------------
. (Join-Path ([System.IO.Path]::GetDirectoryName($MyInvocation.MyCommand.Definition)) "Microsoft.Rba.LogFunctions.ps1")
. (Join-Path ([System.IO.Path]::GetDirectoryName($MyInvocation.MyCommand.Definition)) "Microsoft.Rba.CoreHelper.ps1")
