﻿Function Get-LargeADGroupMember{
[CmdletBinding()]
Param($name="HugeGroup")
    $grpName = (Get-ADGroup -Identity $name).DistinguishedName
    $group =[adsi]"LDAP://$grpName"
    # Retrieve all group members
    $members = $group.psbase.invoke("Members") | foreach {$_.GetType().InvokeMember("Name",'GetProperty',$null,$_,$null)} 
    # Bind to group members
    $names = $members | foreach { $name = $_ -replace 'CN='; (Get-ADUser -Filter {Name -eq $name}).DistinguishedName }
    $names
    $members.count
}
