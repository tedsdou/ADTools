﻿Function Add-TestADUsers{
1..1000 | ForEach-Object{
    $Surname = ("Smith","Neo","Trinity","Morpheus","Cipher","Tank","Dozer","Switch","Mouse") | Get-Random
    [pscustomobject]@{
        SamAccountName = "test$_"
        Name = "test$_ $Surname"
        Surname = $Surname
        DisplayName = "$Surname, Test$_"
        Enabled = "TRUE"
        Office = ("Chicago","Athens","New York","San Diego","Miami","Boston","Philadelphia") | Get-Random
       }
    } | Export-Csv -Path C:\Temp\testAccounts.csv
    Write-Warning "Test users have been built.  CSV is at c:\temp\testAccounts.csv"
}