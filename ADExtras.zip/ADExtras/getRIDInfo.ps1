﻿function Get-RemainingRID

{
    param ($domainDN = (Get-ADDomain).distinguishedName)
    $property = Get-ADObject "cn=rid manager$,cn=system,$domainDN" `
        -Property rIDAvailablePool -server ((Get-ADDomain $domaindn).RidMaster)
    $rid = $property.rIDAvailablePool   
    [int32]$totalSIDS = $($rid) / ([math]::Pow(2,32))
    [int64]$temp64val = $totalSIDS * ([math]::Pow(2,32))
    [int32]$currentRIDPoolCount = $($rid) - $temp64val
    $ridsremaining = $totalSIDS - $currentRIDPoolCount
    Write-Host "SIDs issued: $("{0:N0}" -f $currentRIDPoolCount)"
    Write-Host "SIDs remaining: $("{0:N0}" -f $ridsremaining)"
}