﻿#Remove orphaned GPTs
Function Remove-OrphanedGPT
{
[CmdletBinding(SupportsShouldProcess=$true,ConfirmImpact='High')]
    $gpos = Get-GPO  -All
    $guids = $gpos | ForEach-Object { "{$($_.Id.Guid)}" }
    $files = Get-ChildItem -Path "\\$env:USERDNSDOMAIN\SYSVOL\$env:USERDNSDOMAIN\Policies" | 
        Where-Object {($_.Name -notin $guids) -and ($_.Name -ne 'PolicyDefinitions')}
    $files | ForEach-Object {
      if ($pscmdlet.ShouldProcess("$env:USERDOMAIN", "Removing orphaned GPT: $_"))
            {
                Write-Output "Deleting orphaned GPO, $($_.Name)..."
                $_ | Remove-Item -Recurse -Confirm:$false
            }
      } 
}
