Function Get-TempPassword() {
#Taken from http://blogs.technet.com/b/heyscriptingguy/archive/2013/06/03/generating-a-new-password-with-windows-powershell.aspx
Param([int]$length=10)

$ascii=$NULL;For ($a=33;$a �le 126;$a++) {$ascii+=,[char][byte]$a }

For ($loop=1; $loop �le $length; $loop++) {
            $TempPassword+=($ascii | Get-Random)
            }

    $TempPassword
}